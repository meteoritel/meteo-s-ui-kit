package com.meteorite.meteosuikit.api.layout;

import com.meteorite.meteosuikit.api.input.UiAction;
import com.meteorite.meteosuikit.api.geometry.UiTransform;
import com.meteorite.meteosuikit.api.render.UiIcon;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_2561;

/** 只读文档的逻辑内容；阅读控件解释动作，宿主解释业务 payload，Frame 提供一层内容视口。 */
public sealed interface UiNode permits UiNode.Row, UiNode.Gap, UiNode.Divider, UiNode.Frame {
    /** 树的根行没有父行。 */
    int NO_PARENT = -1;

    /**
     * 自然宽度的缩进行，**行首图标**后跟文字，文字后可跟多个各自带命中信息的图标。
     * {@code parentRow} 是同一内容列表中位于本行之前的父 Row 下标（{@link #NO_PARENT} 表示根行）；
     * 连线几何由排版阶段按父子矩形推导，构建方只需给出父子关系。
     *
     * @param leading 行首图标（画在缩进之后、文字之前），物品清单每行「图标 + 名称」用它；
     *                为 {@code null} 时行为与只有文字的旧行一致
     */
    record Row(int indent, int parentRow, @Nullable InlineIcon leading, class_2561 text, int color,
               List<InlineIcon> icons,
               List<class_2561> tooltip, @Nullable Object payload, @Nullable UiAction action) implements UiNode {
        public Row {
            if (indent < 0) throw new IllegalArgumentException("Negative row indent");
            if (parentRow < NO_PARENT) throw new IllegalArgumentException("Invalid row parent");
            text = Objects.requireNonNull(text).method_27661();
            icons = List.copyOf(icons);
            tooltip = copyTooltip(tooltip);
        }

        public Row(int indent, int parentRow, class_2561 text, int color, List<InlineIcon> icons,
                   List<class_2561> tooltip, @Nullable Object payload, @Nullable UiAction action) {
            this(indent, parentRow, null, text, color, icons, tooltip, payload, action);
        }

        public Row(class_2561 text, int color) {
            this(0, NO_PARENT, null, text, color, List.of(), List.of(), null, null);
        }
    }

    /** 行内图标的独立命中数据；空提示仍会阻止同一位置回退到行提示。 */
    record InlineIcon(UiIcon icon, List<class_2561> tooltip, @Nullable Object payload, @Nullable UiAction action) {
        public InlineIcon {
            Objects.requireNonNull(icon);
            tooltip = copyTooltip(tooltip);
        }
    }

    /** 固定高度的空白。 */
    record Gap(int height) implements UiNode {
        public Gap {
            if (height < 0) throw new IllegalArgumentException("Negative gap");
        }
    }

    /** 宽度跟随文档视口的单像素分隔线。 */
    record Divider(int color) implements UiNode {}

    /** 固定大小的裁剪视口，变换对象由业务方持有以便保存场景状态；连线颜色归框所有（见 {@link Row#parentRow()}）。 */
    record FrameSpec(int width, int height, int branchColor, UiTransform transform) {
        public FrameSpec {
            if (width <= 0 || height <= 0) throw new IllegalArgumentException("Empty frame");
            Objects.requireNonNull(transform);
        }
    }

    /** 文档内容的裁剪视口；宿主解释命中结果并管理边框、视口操作与输入。 */
    record Frame(FrameSpec spec, List<UiNode> content) implements UiNode {
        public Frame {
            Objects.requireNonNull(spec);
            content = List.copyOf(content);
            for (UiNode node : content) {
                if (node instanceof Frame) throw new IllegalArgumentException("Nested frames are not supported");
            }
        }
    }

    private static List<class_2561> copyTooltip(List<class_2561> tooltip) {
        return tooltip.stream().map(component -> (class_2561) component.method_27661()).toList();
    }
}
