package com.meteorite.meteosuikit.api.preview;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

/** 原版结构格式的不可变快照；多调色板固定使用第一组。 */
public record PreviewStructure(class_2338 size, List<class_2680> palette, List<Cell> blocks,
                               List<Actor> entities) {
    // 外部可达性搜索也占内存，在分配占位数组前约束体积。
    static final int MAX_CELLS = 1_048_576;

    public PreviewStructure {
        size = size.method_10062();
        validateSize(size);
        palette = List.copyOf(palette);
        blocks = List.copyOf(blocks);
        entities = List.copyOf(entities);
        HashSet<class_2338> occupied = new HashSet<>();
        for (Cell cell : blocks) {
            class_2338 p = cell.pos();
            if (p.method_10263() < 0 || p.method_10264() < 0 || p.method_10260() < 0 || p.method_10263() >= size.method_10263()
                    || p.method_10264() >= size.method_10264() || p.method_10260() >= size.method_10260())
                throw new IllegalArgumentException("方块坐标越界: " + p);
            if (cell.state() < 0 || cell.state() >= palette.size())
                throw new IllegalArgumentException("调色板引用越界: " + cell.state());
            if (!occupied.add(p)) throw new IllegalArgumentException("重复方块坐标: " + p);
        }
    }

    /** 逐格记录保留完整 NBT；位置为结构局部坐标。 */
    public record Cell(class_2338 pos, int state, @Nullable class_2487 data) {
        public Cell { pos = pos.method_10062(); data = data == null ? null : data.method_10553(); }
        /** 返回独立方块实体载荷。 */
        @Override public @Nullable class_2487 data() { return data == null ? null : data.method_10553(); }
    }

    /** 实体位置、锚点和包含 Rotation 的原始载荷。 */
    public record Actor(class_243 pos, class_2338 blockPos, class_2487 data) {
        public Actor {
            blockPos = blockPos.method_10062();
            data = data.method_10553();
            if (!Double.isFinite(pos.field_1352) || !Double.isFinite(pos.field_1351) || !Double.isFinite(pos.field_1350))
                throw new IllegalArgumentException("实体位置包含非有限数值");
        }
        /** 返回独立实体载荷。 */
        @Override public class_2487 data() { return data.method_10553(); }
    }

    /** 解码 Minecraft 1.21.1 structure NBT，在索引前校验尺寸、坐标与调色板引用。 */
    public static PreviewStructure decode(class_2487 root) {
        class_2338 size = position(root.method_10554("size", class_2520.field_33253));
        validateSize(size);
        class_2499 rawPalette = root.method_10573("palettes", class_2520.field_33259)
                ? root.method_10554("palettes", class_2520.field_33259).method_10603(0)
                : root.method_10554("palette", class_2520.field_33260);
        List<class_2680> palette = new ArrayList<>();
        for (int i = 0; i < rawPalette.size(); i++) {
            class_2487 state = rawPalette.method_10602(i);
            if (!class_7923.field_41175.method_10250(class_2960.method_60654(state.method_10558("Name"))))
                throw new IllegalArgumentException("未注册方块: " + state.method_10558("Name"));
            palette.add(class_2512.method_10681(class_7923.field_41175.method_46771(), state));
        }
        List<Cell> blocks = new ArrayList<>();
        for (class_2520 tag : root.method_10554("blocks", class_2520.field_33260)) {
            class_2487 cell = (class_2487) tag;
            blocks.add(new Cell(position(cell.method_10554("pos", class_2520.field_33253)), cell.method_10550("state"),
                    cell.method_10573("nbt", class_2520.field_33260) ? cell.method_10562("nbt") : null));
        }
        List<Actor> entities = new ArrayList<>();
        for (class_2520 tag : root.method_10554("entities", class_2520.field_33260)) {
            class_2487 actor = (class_2487) tag;
            class_2499 pos = actor.method_10554("pos", class_2520.field_33256);
            if (pos.size() != 3 || !actor.method_10573("nbt", class_2520.field_33260))
                throw new IllegalArgumentException("结构实体缺少位置或载荷");
            entities.add(new Actor(new class_243(pos.method_10611(0), pos.method_10611(1), pos.method_10611(2)),
                    position(actor.method_10554("blockPos", class_2520.field_33253)), actor.method_10562("nbt")));
        }
        return new PreviewStructure(size, palette, blocks, entities);
    }

    private static class_2338 position(class_2499 values) {
        if (values.size() != 3) throw new IllegalArgumentException("结构坐标必须包含三个整数");
        return new class_2338(values.method_10600(0), values.method_10600(1), values.method_10600(2));
    }

    private static void validateSize(class_2338 size) {
        if (size.method_10263() <= 0 || size.method_10264() <= 0 || size.method_10260() <= 0
                || size.method_10263() > MAX_CELLS || size.method_10264() > MAX_CELLS || size.method_10260() > MAX_CELLS
                || (long) size.method_10263() * size.method_10264() > MAX_CELLS
                || (long) size.method_10263() * size.method_10264() * size.method_10260() > MAX_CELLS)
            throw new IllegalArgumentException("结构尺寸超限: " + size);
    }
}
