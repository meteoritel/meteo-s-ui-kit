package com.meteorite.meteosuikit.api.text;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2477;
import net.minecraft.class_2583;
import net.minecraft.class_327;
import net.minecraft.class_5225;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

/** 有行数上限的格式化文本排版，逻辑裁剪完成后统一执行视觉排序。 */
public final class TextWrap {
    private static final String ELLIPSIS = "...";

    private TextWrap() { }

    /**
     * 折行并返回可绘制的视觉序列，超出行数时在最后可见行追加 ASCII 省略号。
     * 宽度或行数非正时返回空列表；后缀放不下时只裁剪内容，保留完整码点和原有 Style。
     */
    public static List<class_5481> fit(class_327 font, class_5348 text, int width, int maxLines) {
        if (width <= 0 || maxLines <= 0) return List.of();
        class_5225 splitter = font.method_27527();
        List<class_5348> lines = splitter.method_27495(text, width, class_2583.field_24360);
        int count = Math.min(lines.size(), maxLines);
        List<class_5481> result = new ArrayList<>(count);
        int suffixWidth = font.method_1727(ELLIPSIS);
        for (int index = 0; index < count; index++) {
            class_5348 line = lines.get(index);
            if (index == count - 1 && lines.size() > count && suffixWidth <= width) {
                line = class_5348.method_29433(splitter.method_27490(line, width - suffixWidth, class_2583.field_24360),
                        class_5348.method_29430(ELLIPSIS));
            } else {
                line = splitter.method_27490(line, width, class_2583.field_24360);
            }
            result.add(class_2477.method_10517().method_30934(line));
        }
        return List.copyOf(result);
    }
}
