package com.meteorite.meteosuikit.internal.preview.mixin;

import net.minecraft.class_8113;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

/** 仅由独立预览实例调用，直接装配显示快照，保持实体不 tick。 */
@Mixin(class_8113.class)
public interface DisplayPreviewAccessor {
    /** 创建当前 NBT 对应的静态变换与 billboard 状态。 */
    @Invoker("createFreshRenderState")
    class_8113.class_8229 previewCreateRenderState();

    /** 安装渲染快照。 */
    @Accessor("renderState")
    void previewSetRenderState(class_8113.class_8229 state);

    /** 装配 block/item/text 专属的渲染快照。 */
    @Invoker("updateRenderSubState")
    void previewUpdateSubState(boolean interpolate, float progress);

}
