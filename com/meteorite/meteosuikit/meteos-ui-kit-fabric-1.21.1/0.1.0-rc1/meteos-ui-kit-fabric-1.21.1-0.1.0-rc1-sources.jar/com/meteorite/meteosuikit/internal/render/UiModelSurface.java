package com.meteorite.meteosuikit.internal.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.meteorite.meteosuikit.api.geometry.UiRect;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_1921;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4722;
import net.minecraft.class_6367;
import net.minecraft.class_757;
import net.minecraft.class_8251;
import net.minecraft.class_9799;
import net.minecraft.class_9801;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL30;

/** 渲染线程共用的模型工作区；内部深度只参与模型绘制，合成时回到调用方的平面。 */
public final class UiModelSurface {
    private static UiModelSurface shared;
    private final Map<class_1921, class_1921> layers = new IdentityHashMap<>();
    private final class_9799 arena = new class_9799(class_1921.field_32774);
    private final ModelBuffers buffers = new ModelBuffers();
    private class_6367 target;

    private UiModelSurface() { }

    /** 在当前 pose 与裁剪范围内绘制；同一工作区逐枚复用，不保留图标颜色缓存。 */
    public static void draw(class_332 graphics, UiRect box, Consumer<class_332> painter) {
        if (box.width() <= 0 || box.height() <= 0) return;
        if (shared == null) shared = new UiModelSurface();
        shared.render(graphics, box, painter);
    }

    /** 客户端资源世代失效或终止时在渲染线程释放共享 GPU 与顶点缓冲；下次绘制按需创建。 */
    public static void release() {
        if (shared == null) return;
        if (shared.target != null) shared.target.method_1238();
        shared.buffers.release();
        shared.arena.close();
        shared = null;
    }

    private void render(class_332 graphics, UiRect box, Consumer<class_332> painter) {
        graphics.method_51452();
        int[] viewport = new int[4];
        int[] scissor = new int[4];
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, viewport);
        GL11.glGetIntegerv(GL11.GL_SCISSOR_BOX, scissor);
        boolean clipped = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
        double guiScale = class_310.method_1551().method_22683().method_4495();
        Matrix4f pose = graphics.method_51448().method_23760().method_23761();
        float minX = Float.POSITIVE_INFINITY, minY = Float.POSITIVE_INFINITY;
        float maxX = Float.NEGATIVE_INFINITY, maxY = Float.NEGATIVE_INFINITY;
        for (int x : new int[]{box.x(), box.right()}) for (int y : new int[]{box.y(), box.bottom()}) {
            float screenX = pose.m00() * x + pose.m10() * y + pose.m30();
            float screenY = pose.m01() * x + pose.m11() * y + pose.m31();
            minX = Math.min(minX, screenX); maxX = Math.max(maxX, screenX);
            minY = Math.min(minY, screenY); maxY = Math.max(maxY, screenY);
        }
        int left = Math.max(viewport[0], viewport[0] + (int) Math.floor(minX * guiScale));
        int right = Math.min(viewport[0] + viewport[2], viewport[0] + (int) Math.ceil(maxX * guiScale));
        int bottom = Math.max(viewport[1], viewport[1] + viewport[3] - (int) Math.ceil(maxY * guiScale));
        int top = Math.min(viewport[1] + viewport[3], viewport[1] + viewport[3] - (int) Math.floor(minY * guiScale));
        if (clipped) {
            left = Math.max(left, scissor[0]); right = Math.min(right, scissor[0] + scissor[2]);
            bottom = Math.max(bottom, scissor[1]); top = Math.min(top, scissor[1] + scissor[3]);
        }
        int width = right - left, height = top - bottom;
        if (width <= 0 || height <= 0) return;
        int drawTarget = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        int readTarget = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        Matrix4f projection = new Matrix4f(RenderSystem.getProjectionMatrix());
        class_8251 sorting = RenderSystem.getVertexSorting();
        boolean depth = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
        boolean depthWrite = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
        int depthFunction = GL11.glGetInteger(GL11.GL_DEPTH_FUNC);
        boolean blend = GL11.glIsEnabled(GL11.GL_BLEND);
        int sourceRgb = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB), destinationRgb = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
        int sourceAlpha = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA), destinationAlpha = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
        var shader = RenderSystem.getShader();
        int texture = RenderSystem.getShaderTexture(0);
        float[] color = RenderSystem.getShaderColor().clone();
        float[] clearColor = new float[4];
        GL11.glGetFloatv(GL11.GL_COLOR_CLEAR_VALUE, clearColor);
        double clearDepth = GL11.glGetDouble(GL11.GL_DEPTH_CLEAR_VALUE);
        class_332 local = new class_332(class_310.method_1551(), buffers);
        local.method_51448().method_23760().method_23761().set(pose).m32(0);
        local.method_51448().method_23760().method_23762().set(graphics.method_51448().method_23760().method_23762());
        try {
            RenderSystem.disableScissor();
            ensureSize(width, height);
            RenderSystem.depthMask(true);
            target.method_1230(class_310.field_1703);
            target.method_1235(false);
            RenderSystem.viewport(0, 0, width, height);
            Matrix4f cropped = new Matrix4f().translation(
                    (viewport[2] - 2F * (left - viewport[0]) - width) / width,
                    (viewport[3] - 2F * (bottom - viewport[1]) - height) / height, 0)
                    .scale((float) viewport[2] / width, (float) viewport[3] / height, 1).mul(projection);
            RenderSystem.setProjectionMatrix(cropped, sorting);
            RenderSystem.setShaderColor(1, 1, 1, 1);
            try { painter.accept(local); }
            finally { local.method_51452(); }
            restoreTarget(drawTarget, readTarget, viewport, clipped, scissor);
            RenderSystem.setProjectionMatrix(projection, sorting);
            composite((left - viewport[0]) / (float) guiScale,
                    (viewport[1] + viewport[3] - top) / (float) guiScale,
                    width / (float) guiScale, height / (float) guiScale, pose.m32(), width, height, color);
        } finally {
            restoreTarget(drawTarget, readTarget, viewport, clipped, scissor);
            RenderSystem.setProjectionMatrix(projection, sorting);
            RenderSystem.setShader(() -> shader);
            RenderSystem.setShaderTexture(0, texture);
            RenderSystem.setShaderColor(color[0], color[1], color[2], color[3]);
            RenderSystem.blendFuncSeparate(sourceRgb, destinationRgb, sourceAlpha, destinationAlpha);
            if (blend) RenderSystem.enableBlend(); else RenderSystem.disableBlend();
            RenderSystem.depthMask(depthWrite);
            RenderSystem.depthFunc(depthFunction);
            if (depth) RenderSystem.enableDepthTest(); else RenderSystem.disableDepthTest();
            GlStateManager._clearColor(clearColor[0], clearColor[1], clearColor[2], clearColor[3]);
            GlStateManager._clearDepth(clearDepth);
        }
    }

    private void ensureSize(int width, int height) {
        if (target == null) {
            target = new class_6367(width, height, true, class_310.field_1703);
            target.method_1236(0, 0, 0, 0);
        } else if (target.field_1482 < width || target.field_1481 < height) {
            target.method_1234(Math.max(target.field_1482, width), Math.max(target.field_1481, height), class_310.field_1703);
        }
    }

    private static void restoreTarget(int draw, int read, int[] viewport, boolean clipped, int[] scissor) {
        GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, draw);
        GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, read);
        RenderSystem.viewport(viewport[0], viewport[1], viewport[2], viewport[3]);
        if (clipped) RenderSystem.enableScissor(scissor[0], scissor[1], scissor[2], scissor[3]);
        else RenderSystem.disableScissor();
    }

    private void composite(float x, float y, float width, float height, float z, int pixelsX, int pixelsY, float[] color) {
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc(GL11.GL_LEQUAL);
        RenderSystem.depthMask(true);
        RenderSystem.enableBlend();
        // 透明工作区已累计 premultiplied RGB，合成时保留透明材质和 glint 的实际颜色。
        RenderSystem.blendFuncSeparate(GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderTexture(0, target.method_30277());
        RenderSystem.setShaderColor(color[0] * color[3], color[1] * color[3], color[2] * color[3], color[3]);
        float u = (float) pixelsX / target.field_1482, v = (float) pixelsY / target.field_1481;
        class_287 quad = RenderSystem.renderThreadTesselator().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        quad.method_22912(x, y + height, z).method_22913(0, 0);
        quad.method_22912(x + width, y + height, z).method_22913(u, 0);
        quad.method_22912(x + width, y, z).method_22913(u, v);
        quad.method_22912(x, y, z).method_22913(0, v);
        class_286.method_43433(quad.method_60800());
    }

    private class_1921 layer(class_1921 type) {
        return layers.computeIfAbsent(type, source -> new class_1921(
                "ui_model", source.method_23031(), source.method_23033(), source.method_22722(), source.method_23037(), source.method_60894(),
                () -> { source.method_23516(); target.method_1235(false); },
                () -> { source.method_23518(); target.method_1235(false); }) {
            @Override public void method_60895(@NotNull class_9801 mesh) {
                method_23516();
                try { class_286.method_43433(mesh); }
                finally { method_23518(); }
            }
        });
    }

    private final class ModelBuffers extends class_4597.class_4598 {
        ModelBuffers() {
            super(arena, new LinkedHashMap<>());
            // 与原版固定缓冲顺序一致，尤其让 glint 在基底材质写入深度后提交。
            for (class_1921 type : new class_1921[]{class_4722.method_24073(), class_4722.method_24074(), class_4722.method_24059(),
                    class_4722.method_24076(), class_4722.method_24067(), class_4722.method_24069(), class_4722.method_24070(),
                    class_4722.method_24071(), class_4722.method_45783(), class_4722.method_24072(), class_1921.method_27949(),
                    class_1921.method_23590(), class_1921.method_30676(), class_1921.method_23591(), class_1921.method_29707(),
                    class_1921.method_23589()}) {
                field_20953.put(layer(type), new class_9799(class_1921.field_32775));
            }
        }
        @Override public @NotNull class_4588 getBuffer(@NotNull class_1921 type) { return super.getBuffer(layer(type)); }
        void release() { field_20953.values().forEach(class_9799::close); }
    }
}
