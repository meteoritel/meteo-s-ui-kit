package com.meteorite.meteosuikit.api.preview;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;
import com.meteorite.meteosuikit.api.render.UiModelBounds;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CancellationException;
import java.util.function.Function;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_291;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_778;
import net.minecraft.class_8251;
import net.minecraft.class_9799;
import net.minecraft.class_9801;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL30;

/** 静态几何的编译、交接与 GPU 生命周期；分段只决定工作顺序，缓冲按 RenderType 合并。 */
@SuppressWarnings("resource") // 构建缓冲由 Prepared 持有，跨线程交接后统一 close。
final class SceneMeshes {
    private SceneMeshes() { }

    static final class TooLarge extends RuntimeException {
        TooLarge(long limit) { super("单场景几何超过 " + limit + " bytes"); }
    }

    static final class Building implements AutoCloseable {
        final class_9799 arena = new class_9799(4096);
        final class_287 vertices = new class_287(arena, class_293.class_5596.field_27382, class_290.field_1590);
        final class_9799 indices = new class_9799(1024);
        @Nullable class_9801 mesh;
        @Nullable class_9801.class_9802 sorting;
        int vertexCount;
        long bytes;
        @Override public void close() {
            if (mesh != null) { mesh.close(); mesh = null; }
            indices.close(); arena.close();
        }
    }

    static final class Prepared implements AutoCloseable {
        final Map<class_1921, Building> layers = new LinkedHashMap<>();
        @Nullable UiModelBounds bounds;
        long bytes;
        boolean exceeded;
        @Override public void close() { layers.values().forEach(Building::close); layers.clear(); }
    }

    static Prepared compile(SceneBlocks blocks, PreviewScenes.Geometry geometry, boolean cull, long byteLimit) {
        Prepared result = new Prepared();
        Function<class_1921, class_4588> buffers = budgetedBuffers(result, byteLimit);
        class_778.method_20544();
        try {
            compileBlocks(blocks, geometry, cull, buffers);
            finish(result, byteLimit);
            return result;
        } catch (RuntimeException exception) {
            result.close();
            // 原版 dispatcher 会包装顶点提交异常，预算终态仍按原始触发原因分类。
            if (result.exceeded) throw new TooLarge(byteLimit);
            throw exception;
        }
        finally { class_778.method_20545(); }
    }

    private static Function<class_1921, class_4588> budgetedBuffers(Prepared result, long byteLimit) {
        long[] allocated = {0};
        return type -> {
            Building layer = result.layers.computeIfAbsent(type, ignored -> new Building());
            return new SceneVertices(layer.vertices, 0, 0, 0, () -> {
                int before = layer.vertexCount++;
                long oldIndices = (long) (before / 4) * 6 * class_293.class_5595.method_31972(before).field_27375;
                long newIndices = (long) (layer.vertexCount / 4) * 6 * class_293.class_5595.method_31972(layer.vertexCount).field_27375;
                allocated[0] += class_290.field_1590.method_1362() + newIndices - oldIndices;
                if (allocated[0] > byteLimit) { result.exceeded = true; throw new TooLarge(byteLimit); }
            });
        };
    }

    private static void compileBlocks(SceneBlocks blocks, PreviewScenes.Geometry geometry, boolean cull,
        Function<class_1921, class_4588> buffers) {
        BitSet mask = blocks.visible(cull);
        List<PreviewStructure.Cell> cells = new ArrayList<>(blocks.structure.blocks());
        cells.sort(Comparator.comparingInt((PreviewStructure.Cell cell) -> cell.pos().method_10264() >> 4)
                .thenComparingInt(cell -> cell.pos().method_10260() >> 4).thenComparingInt(cell -> cell.pos().method_10263() >> 4));
        class_4587 pose = new class_4587();
        class_5819 random = class_5819.method_43049(42);
        class_2338 section = null;
        for (PreviewStructure.Cell cell : cells) {
            class_2338 pos = cell.pos();
            class_2338 nextSection = new class_2338(pos.method_10263() >> 4, pos.method_10264() >> 4, pos.method_10260() >> 4);
            if (!nextSection.equals(section)) {
                if (Thread.currentThread().isInterrupted()) throw new CancellationException();
                section = nextSection;
            }
            if (!blocks.visible(mask, pos)) continue;
            var state = blocks.method_8320(pos);
            if (state.method_26217() == class_2464.field_11458) {
                pose.method_22903();
                try {
                    pose.method_46416(pos.method_10263(), pos.method_10264(), pos.method_10260());
                    geometry.block(state, pos, blocks, pose, buffers, random);
                } finally { pose.method_22909(); }
            }
            var fluid = state.method_26227();
            if (!fluid.method_15769()) geometry.fluid(pos, blocks, type -> new SceneVertices(buffers.apply(type),
                    pos.method_10263() & ~15, pos.method_10264() & ~15, pos.method_10260() & ~15), state, fluid);
        }
    }

    private static void finish(Prepared result, long byteLimit) {
        float minX = Float.POSITIVE_INFINITY, minY = Float.POSITIVE_INFINITY, minZ = Float.POSITIVE_INFINITY;
        float maxX = Float.NEGATIVE_INFINITY, maxY = Float.NEGATIVE_INFINITY, maxZ = Float.NEGATIVE_INFINITY;
        for (var entry : result.layers.entrySet()) {
            Building layer = entry.getValue();
            layer.mesh = layer.vertices.method_60794();
            if (layer.mesh == null) continue;
            class_9801.class_4574 draw = layer.mesh.method_60822();
            if (entry.getKey() == class_1921.method_23583())
                layer.sorting = layer.mesh.method_60819(layer.indices, class_8251.field_43360);
            layer.bytes = (long) draw.comp_750() * draw.comp_749().method_1362()
                    + (long) draw.comp_751() * draw.comp_753().field_27375;
            result.bytes += layer.bytes;
            if (result.bytes > byteLimit) throw new TooLarge(byteLimit);
            ByteBuffer data = layer.mesh.method_60818().order(ByteOrder.nativeOrder());
            for (int i = 0; i < draw.comp_750(); i++) {
                int offset = i * draw.comp_749().method_1362();
                float x = data.getFloat(offset), y = data.getFloat(offset + 4), z = data.getFloat(offset + 8);
                minX = Math.min(minX, x); minY = Math.min(minY, y); minZ = Math.min(minZ, z);
                maxX = Math.max(maxX, x); maxY = Math.max(maxY, y); maxZ = Math.max(maxZ, z);
            }
        }
        if (Float.isFinite(minX)) result.bounds = new UiModelBounds((minX + maxX) / 2, (minY + maxY) / 2,
                (minZ + maxZ) / 2, maxX - minX, maxY - minY, maxZ - minZ);
    }

    static final class Layer implements AutoCloseable {
        final class_1921 type;
        final class_291 gpu = new class_291(class_291.class_8555.field_44793);
        final @Nullable class_9801.class_9802 sorting;
        private int sortKey = Integer.MIN_VALUE;

        Layer(class_1921 type, Building source) {
            this.type = type; sorting = source.sorting;
            gpu.method_1353();
            try {
                class_9801 mesh = source.mesh;
                source.mesh = null;
                if (mesh != null) gpu.method_1352(mesh);
            } catch (RuntimeException exception) { gpu.close(); throw exception; }
            finally { class_291.method_1354(); }
        }

        void draw(Matrix4f matrix, UiSceneCamera camera, int target) {
            type.method_23516();
            try {
                GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, target);
                gpu.method_1353();
                int key = Math.floorMod((int) Math.floor(Math.toDegrees(camera.yaw()) / 15), 24)
                        + 24 * Math.round((float) Math.toDegrees(camera.pitch()));
                if (sorting != null && key != sortKey) {
                    try (class_9799 indices = new class_9799(Math.max(1024, sorting.comp_2840().length * 24))) {
                        var result = sorting.method_60824(indices, viewSorting(camera));
                        if (result != null) gpu.method_60829(result);
                    }
                    sortKey = key;
                }
                var shader = RenderSystem.getShader();
                if (shader == null) throw new IllegalStateException("渲染层未绑定 shader: " + type);
                var offset = shader.method_34582("ChunkOffset");
                if (offset != null) offset.method_1249(0F, 0F, 0F);
                gpu.method_34427(matrix, RenderSystem.getProjectionMatrix(), shader);
            } finally {
                class_291.method_1354();
                type.method_23518();
                GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, target);
            }
        }
        @Override public void close() { gpu.close(); }
    }

    static class_8251 viewSorting(UiSceneCamera camera) {
        float sy = (float) Math.sin(camera.yaw()), cy = (float) Math.cos(camera.yaw());
        float sp = (float) Math.sin(camera.pitch()), cp = (float) Math.cos(camera.pitch());
        // GUI 中更小的 z 更远，按预览变换后的深度从远到近提交。
        return class_8251.method_49907(v -> sy * cp * v.x - sp * v.y - cy * cp * v.z);
    }
}
