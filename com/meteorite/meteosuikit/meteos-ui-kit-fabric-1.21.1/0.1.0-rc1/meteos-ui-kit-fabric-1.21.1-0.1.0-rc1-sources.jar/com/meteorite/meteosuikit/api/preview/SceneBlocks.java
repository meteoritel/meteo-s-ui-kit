package com.meteorite.meteosuikit.api.preview;

import java.util.BitSet;
import net.minecraft.class_1163;
import net.minecraft.class_1920;
import net.minecraft.class_1944;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3568;
import net.minecraft.class_3610;
import net.minecraft.class_6539;
import org.jetbrains.annotations.Nullable;

import org.jetbrains.annotations.NotNull;

/** 完整占位与静态提交掩码分开持有，剔除后邻面、AO 和 tint 仍读取原始场景。 */
final class SceneBlocks implements class_1920 {
    final PreviewStructure structure;
    private final class_2680[] states;
    private final int sx, sy, sz;
    private final @Nullable class_1959 fallbackBiome;

    SceneBlocks(PreviewStructure structure, @Nullable class_1959 fallbackBiome) {
        this.structure = structure;
        sx = structure.size().method_10263(); sy = structure.size().method_10264(); sz = structure.size().method_10260();
        states = new class_2680[sx * sy * sz];
        this.fallbackBiome = fallbackBiome;
        for (PreviewStructure.Cell cell : structure.blocks())
            states[index(cell.pos().method_10263(), cell.pos().method_10264(), cell.pos().method_10260())] = structure.palette().get(cell.state());
    }

    private int index(int x, int y, int z) { return (y * sz + z) * sx + x; }

    @Override public @NotNull class_2680 method_8320(@NotNull class_2338 pos) {
        int x = pos.method_10263(), y = pos.method_10264(), z = pos.method_10260();
        if (x < 0 || y < 0 || z < 0 || x >= sx || y >= sy || z >= sz) return class_2246.field_10124.method_9564();
        class_2680 state = states[index(x, y, z)];
        return state == null ? class_2246.field_10124.method_9564() : state;
    }
    @Override public @NotNull class_3610 method_8316(@NotNull class_2338 pos) { return method_8320(pos).method_26227(); }
    @Override public @Nullable class_2586 method_8321(@NotNull class_2338 pos) { return null; }
    @Override public float method_24852(@NotNull class_2350 direction, boolean shade) { return 1; }
    @Override public int method_8314(@NotNull class_1944 layer, @NotNull class_2338 pos) { return 15; }
    @Override public int method_22335(@NotNull class_2338 pos, int amount) { return 15; }
    @Override public @NotNull class_3568 method_22336() {
        throw new UnsupportedOperationException("预览占位直接提供满亮查询");
    }
    @Override public int method_31605() { return sy; }
    @Override public int method_31607() { return 0; }
    @Override public int method_23752(@NotNull class_2338 pos, @NotNull class_6539 resolver) {
        if (resolver == class_1163.field_5665) return 0x91BD59;
        if (resolver == class_1163.field_5664) return 0x77AB2F;
        if (resolver == class_1163.field_5666) return 0x3F76E4;
        if (fallbackBiome == null) throw new IllegalStateException("自定义颜色解析器需要客户端群系注册表");
        return resolver.getColor(fallbackBiome, pos.method_10263(), pos.method_10260());
    }

    BitSet visible(boolean cull) {
        BitSet visible = new BitSet(states.length);
        if (!cull) { visible.set(0, states.length); return visible; }
        int wx = sx + 2, wy = sy + 2, wz = sz + 2;
        int count = Math.multiplyExact(Math.multiplyExact(wx, wy), wz);
        BitSet visited = new BitSet(count);
        int[] queue = new int[count];
        int read = 0, write = 1;
        visited.set(0);
        class_2338.class_2339 pos = new class_2338.class_2339();
        while (read < write) {
            if ((read & 4095) == 0 && Thread.currentThread().isInterrupted())
                throw new java.util.concurrent.CancellationException();
            int v = queue[read++], x = v % wx, z = v / wx % wz, y = v / wx / wz;
            for (class_2350 direction : class_2350.values()) {
                int nx = x + direction.method_10148(), ny = y + direction.method_10164(), nz = z + direction.method_10165();
                if (nx < 0 || ny < 0 || nz < 0 || nx >= wx || ny >= wy || nz >= wz) continue;
                pos.method_10103(nx - 1, ny - 1, nz - 1);
                if (nx > 0 && ny > 0 && nz > 0 && nx <= sx && ny <= sy && nz <= sz)
                    visible.set(index(nx - 1, ny - 1, nz - 1));
                int next = (ny * wz + nz) * wx + nx;
                if (!visited.get(next)) {
                    visited.set(next);
                    if (!method_8320(pos).method_26216(this, pos)) queue[write++] = next;
                }
            }
        }
        return visible;
    }

    boolean visible(BitSet mask, class_2338 pos) { return mask.get(index(pos.method_10263(), pos.method_10264(), pos.method_10260())); }
}
