package com.meteorite.meteosuikit.api.control;

import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import com.meteorite.meteosuikit.api.input.UiAction;

import com.meteorite.meteosuikit.api.input.UiPointerHit;
import com.meteorite.meteosuikit.api.input.UiPointer;
import com.meteorite.meteosuikit.api.geometry.UiRect;
import com.meteorite.meteosuikit.api.input.UiFocusState;
import com.meteorite.meteosuikit.api.input.UiFocusTarget;
import com.meteorite.meteosuikit.api.input.UiInputContext;
import com.meteorite.meteosuikit.api.input.UiInputTarget;
import com.meteorite.meteosuikit.api.input.UiInteractionSession;
import com.meteorite.meteosuikit.api.layout.UiLayoutNode;
import com.meteorite.meteosuikit.api.layout.UiLayoutSource;
import com.meteorite.meteosuikit.api.render.UiIcon;
import com.meteorite.meteosuikit.api.style.UiControlStyle;
import com.meteorite.meteosuikit.api.style.UiControlRole;
import com.meteorite.meteosuikit.api.style.UiStyleSource;
import com.meteorite.meteosuikit.api.style.UiMinecraftTheme;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 通用图标条：水平功能栏与竖直工具列共用同一实现，每格是一个只有图标与提示的 {@link UiControl}。
 *
 * <p>本类只负责布局与每格状态：格子背景、悬停/按下/选中/禁用/焦点绘制、tooltip 载体、命中与
 * {@code activate} 全部复用 {@link UiControl}；启用与禁用只决定使用常态还是禁用字形。
 * 输入契约走 kit 的 {@link UiInputTarget} 与 {@link UiFocusTarget}，宿主用一层薄适配接入既有控件分发。</p>
 *
 * <p>{@link #setBounds} 后立即重排，不需要再调用布局方法；不可见的格子不占槽位。
 * 所有格子共用统一尺寸（取可见项图标的最大宽高），因此切换字形不会让图标错位。</p>
 */
public final class UiIconStrip implements UiInteractionSession.Target, UiFocusTarget, UiLayoutSource {

    /**
     * 排列方向：水平功能栏沿 x 排布，竖直工具列沿 y 排布。
     */
    public enum Orientation {HORIZONTAL, VERTICAL}

    /**
     * 单格四周留白：图标与格子边缘的最小距离。
     */
    private static final int CELL_PADDING = 2;
    /**
     * 空标签占位色：格子只有图标，标签恒为空，该颜色不参与画面。
     */
    private static final int EMPTY_LABEL_COLOR = 0xFFFFFFFF;

    private final class_327 font;
    private final List<Item> cells = new ArrayList<>();
    private Orientation orientation;
    private Supplier<? extends UiStyleSource> theme = () -> UiMinecraftTheme.INSTANCE;
    private UiControlStyle style = theme.get().controlStyle(UiControlRole.SECONDARY);
    private boolean styleOverride;
    private final UiWidgetShell shell = new UiWidgetShell(this);
    private int focusedIndex = -1;
    private int pressedIndex = -1;
    private @Nullable UiInteractionSession session;

    public UiIconStrip(class_327 font, Orientation orientation) {
        this.font = Objects.requireNonNull(font);
        this.orientation = Objects.requireNonNull(orientation);
    }

    /**
     * 加一格：常态与禁用共用同一字形。
     */
    public Item add(UiIcon icon, class_2561 tooltip, UiAction action) {
        return add(icon, icon, tooltip, action);
    }

    /**
     * 加一格：禁用时切换到 {@code disabled} 字形。
     */
    public Item add(UiIcon normal, UiIcon disabled, class_2561 tooltip, UiAction action) {
        Item item = new Item(this, Objects.requireNonNull(normal, "Normal icon"),
                Objects.requireNonNull(disabled, "Disabled icon"), tooltip, action);
        cells.add(item);
        item.applyIcon();
        relayout();
        return item;
    }

    public void setOrientation(Orientation orientation) {
        this.orientation = Objects.requireNonNull(orientation);
        relayout();
    }

    /** 绑定稳定主题来源，显式 setStyle 优先于主题默认项。 */
    public void setTheme(Supplier<? extends UiStyleSource> theme) {
        this.theme = Objects.requireNonNull(theme, "theme");
        styleOverride = false;
        for (Item item : cells) item.control.setTheme(theme, UiControlRole.SECONDARY);
    }

    /**
     * 皮肤注入：只影响格子结构色与焦点轮廓。
     */
    public void setStyle(UiControlStyle style) {
        this.style = Objects.requireNonNull(style);
        styleOverride = true;
        for (Item item : cells) item.control.setStyle(style);
    }

    /** 更新 GUI 逻辑矩形；负宽高按零处理，同步当前布局几何。 */
    public void setBounds(int x, int y, int width, int height) {
        shell.setBounds(x, y, width, height);
        relayout();
    }

    /** {@inheritDoc} */
    @Override
    public UiRect bounds() {
        return shell.bounds();
    }

    /**
     * 量取一组格子横向覆盖的宽度：取可见格子的最右边缘减最左边缘，零可见格子时为 0。
     *
     * <p>只读度量，不改变布局与命中判定；同一图标条内的格子沿排列方向紧邻摆放，因此水平条
     * 用它得到各格宽度之和，竖直条得到单格宽度。宿主借此把底板收窄到最后一格之后，把右侧
     * 空白交还画布，而命中仍按格子矩形处理。</p>
     *
     * @param items 同一图标条内的格子句柄，{@code null} 视为空集合
     * @return 可见格子横向覆盖的宽度
     */
    public static int cellsWidth(@Nullable List<Item> items) {
        if (items == null) {
            return 0;
        }
        int left = Integer.MAX_VALUE;
        int right = Integer.MIN_VALUE;
        for (Item item : items) {
            if (item == null || !item.isVisible()) {
                continue;
            }
            UiRect rect = item.bounds();
            left = Math.min(left, rect.x());
            right = Math.max(right, rect.right());
        }
        return left == Integer.MAX_VALUE ? 0 : Math.max(0, right - left);
    }

    /**
     * 导出图标条的只读排版快照：每个可见格子一个 CONTROL，矩形取该格的真实命中矩形。
     *
     * <p>格子只有图标、没有标签，文案因此取 {@link UiControl#accessibleName()}——它回退到
     * tooltip 首行，正是玩家悬停时看到的名称，探针无需另建一张文案表。不可见格子在重排时已被
     * 压成 0×0，这里直接跳过，避免把空矩形当成可点区域报给调用方；{@code enabled} 取格子的
     * 启用态，选中态只影响绘制，不参与快照。</p>
     */
    @Override
    public List<UiLayoutNode> layoutNodes() {
        List<UiLayoutNode> nodes = new ArrayList<>(cells.size());
        for (Item item : cells) {
            UiControl control = item.control;
            if (!control.isVisible()) continue;
            class_2561 name = control.accessibleName();
            if (name == null) name = class_2561.method_43473();
            UiRect rect = control.bounds();
            nodes.add(new UiLayoutNode(UiLayoutNode.Kind.CONTROL, rect, name, font.method_27525(name),
                    rect.width(), control.isEnabled(), true, List.of()));
        }
        return nodes;
    }

    /**
     * 绘制全部可见格子；{@code mouseX/mouseY} 为宿主 GUI 逻辑坐标。
     */
    public void render(class_332 graphics, UiPointer incomingPointer) {
        UiPointer pointer = incomingPointer.resolve(this).forTarget(this);
        for (int i = 0; i < cells.size(); i++) {
            UiControl control = cells.get(i).control;
            if (!control.isVisible()) continue;

            control.render(graphics, font, pointer);
            if (isFocusVisible() && i == focusedIndex) control.renderFocusOutline(graphics);
        }
    }

    /**
     * 命中格子的提示目标；供宿主显示提示或做光标反馈。
     */
    @Nullable
    public UiPointerHit.TextTooltip hit(double x, double y) {
        int index = indexAt(x, y);
        return index < 0 ? null : cells.get(index).control.hit(x, y);
    }

    // ---------- UiInputTarget ----------

    /**
     * 接收新的左键按压，替换同一图标条上尚未释放的旧按压。
     */
    @Override
    public boolean mousePressed(UiInputContext context) {
        if (context.button() != 0) return false;
        int index = indexAt(context.pointerX(), context.pointerY());
        if (index < 0) return false;
        UiControl control = cells.get(index).control;
        if (!control.isHittable()) return false;

        session = context.scope().interaction();
        session.begin(this, UiInteractionSession.Source.POINTER, 0);
        clearPress();
        control.setPressed(true);
        pressedIndex = index;
        focusedIndex = index;
        return true;
    }

    /**
     * 已按下格子只消费左键拖动，指针离开格子后仍保持归属。
     */
    @Override
    public boolean mouseDragged(UiInputContext context, double dragX, double dragY) {
        return context.button() == GLFW.GLFW_MOUSE_BUTTON_LEFT && pressedIndex >= 0;
    }

    /**
     * 对应左键释放时结束按压，仍命中原格子才激活动作。
     */
    @Override
    public boolean mouseReleased(UiInputContext context) {
        if (context.button() != 0 || pressedIndex < 0) return false;
        int pressed = pressedIndex;
        clearPress();
        // 指针移回同一格才激活；无论是否激活都消费这次释放，避免同一次点击落到画布上。
        if (indexAt(context.pointerX(), context.pointerY()) == pressed) {
            cells.get(pressed).control.activate();
        }
        return true;
    }

    // 方向键在可聚焦格之间移动（横向条用左右，纵向条用上下）；Enter / Space 由焦点管理器走 activate()。
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        int delta = 0;
        if (orientation == Orientation.HORIZONTAL) {
            if (keyCode == GLFW.GLFW_KEY_LEFT) delta = -1;
            else if (keyCode == GLFW.GLFW_KEY_RIGHT) delta = 1;
        } else {
            if (keyCode == GLFW.GLFW_KEY_UP) delta = -1;
            else if (keyCode == GLFW.GLFW_KEY_DOWN) delta = 1;
        }
        return delta != 0 && moveFocus(delta);
    }

    /** {@inheritDoc} */
    @Override
    public UiFocusState focusState() {
        return shell.focusState();
    }

    @Override
    public boolean canFocus() {
        return firstFocusableIndex() >= 0;
    }

    /**
     * 失去焦点作用域时取消尚未释放的格子按压。
     */
    @Override
    public void focusChanged(boolean focused) {
        if (focused && focusedIndex < 0) focusedIndex = firstFocusableIndex();
        if (!isFocused()) {
            clearPress();
            for (Item item : cells) item.control.focusState().clear();
        }
    }

    @Override
    public void interactionEnded(UiInteractionSession.EndReason reason) {
        clearPress();
    }

    private void cancelPress() {
        if (session != null) session.end(this, UiInteractionSession.EndReason.CANCEL);
        clearPress();
    }

    private void clearPress() {
        if (pressedIndex < 0) return;
        cells.get(pressedIndex).control.setPressed(false);
        pressedIndex = -1;
    }

    @Override
    public boolean activate() {
        int index = focusedIndex >= 0 ? focusedIndex : firstFocusableIndex();
        return index >= 0 && cells.get(index).control.activate();
    }

    @Override
    public @Nullable class_2561 accessibleName() {
        int index = focusedIndex >= 0 ? focusedIndex : firstFocusableIndex();
        return index < 0 ? null : cells.get(index).control.accessibleName();
    }

    // ---------- 内部 ----------

    private int indexAt(double x, double y) {
        for (int i = 0; i < cells.size(); i++) {
            UiControl control = cells.get(i).control;
            if (control.isVisible() && control.bounds().contains(x, y)) return i;
        }
        return -1;
    }

    private int firstFocusableIndex() {
        for (int i = 0; i < cells.size(); i++) {
            if (cells.get(i).control.isFocusable()) return i;
        }
        return -1;
    }

    // 在可聚焦格之间环绕移动；当前焦点不在列表里（尚未聚焦或该格被禁用）时从首/末格进入。
    private boolean moveFocus(int delta) {
        List<Integer> focusable = new ArrayList<>();
        for (int i = 0; i < cells.size(); i++) {
            if (cells.get(i).control.isFocusable()) focusable.add(i);
        }
        if (focusable.isEmpty()) return false;
        int position = focusable.indexOf(focusedIndex);
        int next = position < 0
                ? (delta < 0 ? focusable.size() - 1 : 0)
                : Math.floorMod(position + delta, focusable.size());
        focusedIndex = focusable.get(next);

        shell.focusState().request();
        return true;
    }

    // 统一格子尺寸：取可见项两种字形里的最大宽高，再补四周留白。
    private void relayout() {
        boolean anyVisible = false;
        int cellWidth = 0;
        int cellHeight = 0;
        for (Item item : cells) {
            if (!item.control.isVisible()) continue;
            anyVisible = true;
            cellWidth = Math.max(cellWidth, Math.max(item.normal.width(), item.disabled.width()));
            cellHeight = Math.max(cellHeight, Math.max(item.normal.height(), item.disabled.height()));
        }
        if (!anyVisible) {
            for (Item item : cells) item.control.setBounds(0, 0, 0, 0);
            return;
        }
        cellWidth += CELL_PADDING * 2;
        cellHeight += CELL_PADDING * 2;
        if (orientation == Orientation.HORIZONTAL) {
            int y = bounds().y() + Math.max(0, (bounds().height() - cellHeight) / 2);
            int x = bounds().x();
            for (Item item : cells) {
                if (!item.control.isVisible()) {
                    item.control.setBounds(0, 0, 0, 0);
                    continue;
                }
                item.control.setBounds(x, y, cellWidth, cellHeight);
                x += cellWidth;
            }
        } else {
            int x = bounds().x() + Math.max(0, (bounds().width() - cellWidth) / 2);
            int y = bounds().y();
            for (Item item : cells) {
                if (!item.control.isVisible()) {
                    item.control.setBounds(0, 0, 0, 0);
                    continue;
                }
                item.control.setBounds(x, y, cellWidth, cellHeight);
                y += cellHeight;
            }
        }
    }

    /**
     * 图标条的格子句柄：状态变化只影响该格绘制，不重建图标条。
     */
    public static final class Item {
        private final UiIconStrip strip;
        private final UiControl control = new UiControl();
        private final class_2561 tooltipOrNull;
        @Nullable
        private final UiAction action;
        private UiIcon normal;
        private UiIcon disabled;

        private Item(UiIconStrip strip, UiIcon normal, UiIcon disabled,
                     @Nullable class_2561 tooltip, @Nullable UiAction action) {
            this.strip = strip;
            this.normal = normal;
            this.disabled = disabled;
            this.tooltipOrNull = tooltip == null ? null : tooltip.method_27661();
            this.action = action;
            this.control.setTheme(strip.theme, UiControlRole.SECONDARY);
            if (strip.styleOverride) this.control.setStyle(strip.style);
            this.control.setFocusable(action != null);
        }

        /**
         * 禁用当前按压格子时取消该次按压，恢复启用后等待新输入。
         */
        public void setEnabled(boolean value) {
            if (control.isEnabled() == value) return;
            if (!value && strip.pressedIndex >= 0 && strip.cells.get(strip.pressedIndex) == this) strip.cancelPress();
            control.setEnabled(value);
            applyIcon();
        }

        /**
         * 隐藏当前按压格子时取消该次按压，再更新占位布局。
         */
        public void setVisible(boolean value) {
            if (control.isVisible() == value) return;
            if (!value && strip.pressedIndex >= 0 && strip.cells.get(strip.pressedIndex) == this) strip.cancelPress();
            control.setVisible(value);
            strip.relayout();
        }

        /** 业务选中由核心持有，与条内键盘导航分开。 */
        public void setSelected(boolean value) {
            control.setSelected(value);
        }

        /**
         * 切换图标对（例如 JSON 入口在树视图与外置 JSON 视图之间切换）；尺寸变化时重排。
         */
        public void setIcon(UiIcon normal, UiIcon disabled) {
            this.normal = Objects.requireNonNull(normal, "Normal icon");
            this.disabled = Objects.requireNonNull(disabled, "Disabled icon");
            applyIcon();
            strip.relayout();
        }

        /** 当前格子的可用性直接读取核心状态。 */
        public boolean isEnabled() {
            return control.isEnabled();
        }

        /** 当前格子的显隐直接读取核心状态。 */
        public boolean isVisible() {
            return control.isVisible();
        }

        /** 当前格子的业务选中状态。 */
        public boolean isSelected() {
            return control.isSelected();
        }

        public UiRect bounds() {
            return control.bounds();
        }

        // 禁用时换成禁用字形；提示与动作保持不变，因此只需重配一次 UiControl。
        private void applyIcon() {
            control.configure(strip.font, class_2561.method_43473(), EMPTY_LABEL_COLOR,
                    control.isEnabled() ? normal : disabled,
                    tooltipOrNull == null ? List.of() : List.of(tooltipOrNull),
                    action);
        }
    }
    /** 根据实际子控件解析当前命中。 */
    @Override
    public @Nullable UiPointerHit hitTest(double x, double y) {
        int index = indexAt(x, y);
        if (index < 0) return null;
        UiPointerHit hit = cells.get(index).control.hitTest(x, y);
        return hit == null ? null : new UiPointerHit(hit.within(this).owners(), x, y, this, hit.tooltip());
    }
}
