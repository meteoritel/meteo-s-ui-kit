package com.meteorite.meteosuikit.api.control;

import com.meteorite.meteosuikit.api.input.UiFocusState;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3544;
import net.minecraft.class_7530;
import net.minecraft.class_7533;
import com.meteorite.meteosuikit.api.input.UiPointer;
import com.meteorite.meteosuikit.api.input.UiPointerHit;
import com.meteorite.meteosuikit.api.render.UiFlatText;
import com.meteorite.meteosuikit.api.text.UiTextValue;
import com.meteorite.meteosuikit.api.text.UiTextEditSession;
import com.meteorite.meteosuikit.api.input.UiInteractionSession;
import com.meteorite.meteosuikit.api.input.UiInputContext;
import com.meteorite.meteosuikit.api.layout.UiLayoutNode;
import com.meteorite.meteosuikit.api.layout.UiLayoutSource;
import com.meteorite.meteosuikit.api.input.UiHistoryShortcut;
import com.meteorite.meteosuikit.api.geometry.UiRect;
import com.meteorite.meteosuikit.api.style.UiStyleSource;
import com.meteorite.meteosuikit.api.style.UiMinecraftTheme;
import java.util.Objects;

import java.util.ArrayList;
import java.util.List;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

/**
 * 多行文本编辑框：换行、选择、滚动与剪贴板由原版 {@link class_7530} 承担，外观按 kit 主题自绘。
 * <p>与 {@link UiTextInput} 的分工：单行短文本仍走原版 {@code EditBox}；需要同时看到多行或允许换行的字段用本控件。
 * <p>长度上限按 Unicode 码点计数，超限的这一次输入整体回退，不会把半个代理对或超过上限的整段文本写进草稿。
 */
public final class UiTextArea implements UiStatefulWidget, UiTextValue, UiLayoutSource {

    // 左右内边距
    private static final int PADDING_X = TextInputSupport.PADDING_X;
    // 上下内边距
    private static final int PADDING_Y = TextInputSupport.PADDING_Y;
    // 最小宽度
    private static final int MIN_WIDTH = TextInputSupport.MIN_WIDTH;
    // 默认可见行数
    private static final int DEFAULT_ROWS = 3;
    // 内容超出可视高度时的滚动条宽度
    private static final int SCROLLBAR_WIDTH = 3;
    // 光标闪烁周期（毫秒）
    private static final long BLINK_INTERVAL = 300L;

    /** 滚轮动画与编辑光标共用实际视口，光标滚入仍立即定位。 */
    @Override public void advanceFrame(long nowMillis) {
        if (isVisible() && isEnabled()) scroll.advanceFrame(nowMillis);
    }

    /** 退出字段时结清选择及滚动目标。 */
    @Override public void scopeExited(UiInteractionSession.EndReason reason) { endInteraction(reason); }

    private final class_327 font;
    // 文本模型：宽度为 final，宽度变化时按当前值重建
    private AccessibleTextField textField;
    private final UiTextEditSession editSession;
    // 控件矩形
    private final UiWidgetShell shell = new UiWidgetShell(this, this::endInteraction);
    // 已同步到文本模型的换行宽度
    private int textWidth = -1;
    private @Nullable String displayedText;
    private int displayedWidth = -1;
    private List<int[]> displayedLines = List.of();
    // 可见行数
    private int rows = DEFAULT_ROWS;
    // 垂直滚动偏移（像素）
    private final UiScrollView scroll = new UiScrollView();
    // 占位提示
    private @Nullable class_2561 hint;
    // 取消回调（Esc）
    private @Nullable Runnable onCancel;
    // 无障碍名称
    private @Nullable class_2561 accessibleName;
    private boolean editable = true;
    private boolean selectableWhenReadOnly;
    // 获得焦点的时刻，用于光标闪烁
    private long focusedTime;

    // 注入的宿主主题
    private final Supplier<? extends UiStyleSource> theme;

    /** {@inheritDoc} */
    @Override public UiRect bounds() { return shell.bounds(); }
    /** {@inheritDoc} */
    @Override public boolean isEnabled() { return shell.isEnabled(); }
    /** {@inheritDoc} */
    @Override public boolean isVisible() { return shell.isVisible(); }
    /** {@inheritDoc} */
    @Override public UiFocusState focusState() { return shell.focusState(); }
    /** {@inheritDoc} */
    @Override public void setLayoutKey(String key) { shell.setLayoutKey(key); }
    /** {@inheritDoc} */
    @Override public UiTextArea setEnabled(boolean enabled) {
        shell.setEnabled(enabled);
        editSession.setEnabled(enabled);
        return this;
    }

    /** 使用原版默认主题创建多行输入。 */
    public UiTextArea(class_327 font, @Nullable class_2561 hint) { this(() -> UiMinecraftTheme.INSTANCE, font, hint); }

    /** 注入主题并复用原版多行文本模型与 kit 编辑会话。 */
    public UiTextArea(Supplier<? extends UiStyleSource> theme, class_327 font, @Nullable class_2561 hint) {
        this.theme = Objects.requireNonNull(theme, "theme");
        scroll.setScrollbarWidth(SCROLLBAR_WIDTH);
        this.font = font;
        this.hint = hint;
        this.accessibleName = hint;
        this.textField = createField(MIN_WIDTH - PADDING_X * 2 - SCROLLBAR_WIDTH);
        shell.setBounds(0, 0, MIN_WIDTH, height());
        editSession = new UiTextEditSession(new UiTextEditSession.Model() {
            @Override
            public String value() {
                return textField.method_44421();
            }

            @Override
            public void write(String text) {
                textField.method_44414(text);
            }

            @Override
            public void restoreRejected(String text) {
                int cursor = textField.method_44424();
                textField.method_44414(text);
                textField.method_44412(class_7533.field_39535, Math.min(cursor, text.length()));
            }

            @Override
            public int cursor() {
                return textField.method_44424();
            }

            @Override
            public int anchor() {
                return textField.anchor();
            }

            @Override
            public void seek(double pointerX, double pointerY) {
                textField.method_44417(false);
                seekCursor(pointerX, pointerY);
            }

            @Override
            public void select(int anchor, int cursor) {
                textField.method_44417(false);
                textField.method_44412(class_7533.field_39535, anchor);
                textField.method_44417(true);
                textField.method_44412(class_7533.field_39535, cursor);
                textField.method_44417(false);
            }
        }, 1024);
    }

    // 建立文本模型并挂接回调
    private AccessibleTextField createField(int width) {
        AccessibleTextField field = new AccessibleTextField(font, Math.max(8, width));
        field.method_44415(this::onTextChanged);
        field.method_44413(this::scrollToCursor);
        return field;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String value() {
        return textField.method_44421();
    }

    // 程序化设置文本：光标留在末尾，回填路径随后调用 moveCursorToStart()

    /**
     * {@inheritDoc}
     */
    @Override
    public UiTextArea setValue(String value) {
        editSession.backfill(value == null ? "" : value);
        scrollToCursor();
        return this;
    }

    /**
     * 全选原版文本模型并将选择末端滚动进视口。
     */
    @Override
    public UiTextArea selectAll() {
        textField.method_44417(false);
        textField.method_44412(class_7533.field_39535, 0);
        textField.method_44417(true);
        textField.method_44412(class_7533.field_39535, value().length());
        textField.method_44417(false);
        scrollToCursor();
        return this;
    }

    // 设置长度上限（Unicode 码点）

    /**
     * {@inheritDoc}
     */
    @Override
    public UiTextArea setMaxLength(int maxLength) {
        editSession.acceptance().setMaximum(maxLength);
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public UiTextArea setEditable(boolean editable) {
        if (!editable && !selectableWhenReadOnly) endInteraction(UiInteractionSession.EndReason.DISABLED);
        this.editable = editable;
        return this;
    }

    /**
     * 允许只读文本获得焦点、选择和复制；不启用修改或文本局部历史。
     */
    public void setSelectableWhenReadOnly(boolean selectable) {
        if (!selectable && !editable) endInteraction(UiInteractionSession.EndReason.DISABLED);
        this.selectableWhenReadOnly = selectable;
    }

    public void setHint(@Nullable class_2561 hint) {
        this.hint = hint;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public UiTextArea setOnValueChanged(@Nullable Runnable onChanged) {
        editSession.acceptance().setOnChanged(onChanged);
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public UiTextArea setOnOverflow(@Nullable Runnable onOverflow) {
        editSession.acceptance().setOnOverflow(onOverflow);
        return this;
    }

    // 设置取消回调（Esc）
    public void setOnCancel(@Nullable Runnable onCancel) {
        this.onCancel = onCancel;
    }

    public void setRows(int rows) {
        this.rows = Math.max(1, rows);
    }

    public void setAccessibleName(@Nullable class_2561 accessibleName) {
        this.accessibleName = accessibleName;
    }

    /** 隐藏时结束当前交互并退出焦点序列，恢复显示保留内容。 */
    public UiTextArea setVisible(boolean nextVisible) {
        shell.setVisible(nextVisible);
        editSession.setVisible(nextVisible);
        return this;
    }

    // 回填后把光标与垂直滚动复位到开头；编辑期间不调用，避免抢走用户光标

    /**
     * {@inheritDoc}
     */
    @Override
    public UiTextArea moveCursorToStart() {
        textField.method_44412(class_7533.field_39535, 0);
        scroll.setOffset(0);
        clampScroll();
        return this;
    }

    // 控件高度：可见行数加内边距
    public int height() {
        return rows * font.field_2000 + PADDING_Y * 2;
    }

    /** {@inheritDoc} */
    @Override
    public void setBounds(int x, int y, int width, int height) {
        shell.setBounds(x, y, width, height);
        ensureTextWidth();
        clampScroll();
    }

    /**
     * 导出多行输入框的排版快照。
     *
     * <p>多行内容不拆成子节点：节点文案只报首行（空内容时退回占位提示），
     * 宽度按控件内容宽计，探针仍能判断当前行是否横向被裁。纵向可见行数由矩形高度给出。</p>
     */
    @Override
    public List<UiLayoutNode> layoutNodes() {
        if (!isVisible() || bounds().width() <= 0 || bounds().height() <= 0) {
            return List.of();
        }
        String text = value();
        String firstLine = text.isEmpty() ? "" : text.split("\n", 2)[0];
        class_2561 content = firstLine.isEmpty() && hint != null ? hint : class_2561.method_43470(firstLine);
        int budget = Math.max(0, bounds().width() - PADDING_X * 2);
        return List.of(new UiLayoutNode(UiLayoutNode.Kind.TEXT_INPUT, bounds(), content, font.method_27525(content),
                budget, isEnabled() && editable, true, List.of()).identified(shell.layoutKey(), this));
    }

    /** {@inheritDoc} */
    @Override
    public void render(class_332 graphics, class_327 renderFont, UiPointer incomingPointer) {
        if (!isVisible()) {
            return;
        }
        ensureTextWidth();
        syncBounds();
        TextInputSupport.drawBackground(graphics, bounds(), theme);
        int innerX = bounds().x() + PADDING_X;
        int innerY = bounds().y() + PADDING_Y;
        int innerWidth = innerWidth();
        int innerHeight = innerHeight();
        scroll.push(graphics, new UiRect(innerX, innerY, innerWidth + SCROLLBAR_WIDTH, innerHeight));
        try {
            if (textField.method_44421().isEmpty() && !isFocused() && hint != null) {
                UiFlatText.drawWrapped(graphics, renderFont, hint, 0, 0, innerWidth, theme.get().surfaces().disabledText());
            } else {
                renderLines(graphics, font, innerHeight);
            }
        } finally {
            scroll.pop(graphics);
        }
        scroll.renderScrollbar(graphics, theme);
        shell.renderFocusOutline(graphics, bounds(), theme);
    }

    // 逐行绘制文本、选中高亮与光标；行高必须与原版文本模型一致（9 像素）
    private void renderLines(class_332 graphics, class_327 renderFont, int innerHeight) {
        String text = textField.method_44421();
        int cursor = textField.method_44424();
        int[] selection = selectionRange();
        boolean blink = isFocused() && (class_156.method_658() - focusedTime) / BLINK_INTERVAL % 2L == 0L;
        int lineHeight = font.field_2000;
        List<int[]> lines = displayLines();
        for (int index = 0; index < lines.size(); index++) {
            int lineY = index * lineHeight;
            if (lineY + lineHeight < scroll.offset()) {
                continue;
            }
            if (lineY > scroll.offset() + innerHeight) {
                break;
            }
            int begin = lines.get(index)[0];
            int end = lines.get(index)[1];
            if (selection.length == 2) {
                int from = Math.max(selection[0], begin);
                int to = Math.min(selection[1], end);
                if (from < to) {
                    int highlightX = renderFont.method_1727(text.substring(begin, from));
                    int highlightWidth = renderFont.method_1727(text.substring(from, to));
                    theme.get().drawSelection(graphics, new UiRect(highlightX, lineY - 1, Math.max(1, highlightWidth), lineHeight));
                }
            }
            graphics.method_51433(renderFont, text.substring(begin, end), 0, lineY, theme.get().surfaces().inputText(), false);
            if (blink && cursor >= begin && cursor <= end) {
                int cursorX = renderFont.method_1727(text.substring(begin, cursor));
                graphics.method_25294(cursorX - 1, lineY - 1, cursorX + 1, lineY + lineHeight - 1, theme.get().surfaces().inputText());
            }
        }
    }

    // 当前选中区间 [起, 止]，直接使用原版选择锚点，重复文本不影响高亮位置。
    private int[] selectionRange() {
        if (!textField.method_44435()) {
            return new int[0];
        }
        int cursor = textField.method_44424();
        int anchor = textField.anchor();
        return new int[]{Math.min(cursor, anchor), Math.max(cursor, anchor)};
    }

    // 自行折行：与原版文本模型同一套拆分器，保证光标行号与行边界一致
    private List<int[]> displayLines() {
        String text = textField.method_44421();
        int width = innerWidth();
        if (text.equals(displayedText) && width == displayedWidth) return displayedLines;
        List<int[]> lines = new ArrayList<>();
        if (text.isEmpty()) {
            lines.add(new int[]{0, 0});
        } else {
            font.method_27527().method_27485(text, width, class_2583.field_24360, false,
                    (style, begin, end) -> lines.add(new int[]{begin, end}));
            if (text.charAt(text.length() - 1) == '\n') lines.add(new int[]{text.length(), text.length()});
        }
        displayedText = text;
        displayedWidth = width;
        displayedLines = List.copyOf(lines);
        return displayedLines;
    }

    /** {@inheritDoc} */
    @Override
    public boolean mousePressed(UiInputContext context) {
        if (isVisible() && isEnabled() && scroll.mousePressed(context)) return true;
        return editSession.beginSelection(context, bounds(), canFocus());
    }

    @Override
    public boolean mouseReleased(UiInputContext context) {
        return editSession.mouseReleased(context);
    }

    @Override
    public boolean mouseDragged(UiInputContext context, double dragX, double dragY) {
        return editSession.mouseDragged(context, dragX, dragY);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void endInteraction(UiInteractionSession.EndReason reason) {
        scroll.scopeExited(reason);
        editSession.endInteraction(reason);
    }

    /** {@inheritDoc} */
    @Override
    public boolean mouseScrolled(UiInputContext context, double scrollX, double scrollY) {
        double mouseX = context.pointerX();
        double mouseY = context.pointerY();
        if (!isVisible() || !isEnabled() || !bounds().contains(mouseX, mouseY)) {
            return false;
        }
        int maxScroll = maxScroll();
        if (maxScroll <= 0) {
            return false;
        }
        return scroll.scrollByPixels(scrollY * font.field_2000 * 2);
    }

    /** {@inheritDoc} */
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        scroll.endInteraction(UiInteractionSession.EndReason.RELEASE);
        if (!isVisible() || !isEnabled() || !isFocused() || (!editable && !selectableWhenReadOnly)) {
            return false;
        }
        UiHistoryShortcut shortcut = UiHistoryShortcut.fromKey(keyCode, modifiers);
        if (shortcut != null && editable) {
            editSession.applyHistory(shortcut);
            scrollToCursor();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            editSession.endInteraction(UiInteractionSession.EndReason.RELEASE);
            if (onCancel != null) {
                onCancel.run();
                return true;
            }
            return false;
        }
        if (!editable && !isReadOnlyNavigation(keyCode, modifiers)) return false;
        boolean handled = editSession.edit(() -> textField.method_44428(keyCode));
        if (handled) {
            scrollToCursor();
        }
        return handled;
    }

    /** {@inheritDoc} */
    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        scroll.endInteraction(UiInteractionSession.EndReason.RELEASE);
        if (!isVisible() || !isEnabled() || !editable || !isFocused()) {
            return false;
        }
        if (!class_3544.method_57175(codePoint)) {
            return false;
        }
        return editSession.edit(() -> {
            textField.method_44420(Character.toString(codePoint));
            return true;
        });
    }

    /** {@inheritDoc} */
    @Override
    public boolean canFocus() {
        return isVisible() && isEnabled() && (editable || selectableWhenReadOnly);
    }

    private static boolean isReadOnlyNavigation(int keyCode, int modifiers) {
        if ((modifiers & GLFW.GLFW_MOD_CONTROL) != 0
                && (modifiers & (GLFW.GLFW_MOD_ALT | GLFW.GLFW_MOD_SUPER)) == 0
                && (keyCode == GLFW.GLFW_KEY_A || keyCode == GLFW.GLFW_KEY_C)) return true;
        return switch (keyCode) {
            case GLFW.GLFW_KEY_LEFT, GLFW.GLFW_KEY_RIGHT, GLFW.GLFW_KEY_UP, GLFW.GLFW_KEY_DOWN,
                 GLFW.GLFW_KEY_HOME, GLFW.GLFW_KEY_END, GLFW.GLFW_KEY_PAGE_UP, GLFW.GLFW_KEY_PAGE_DOWN -> true;
            default -> false;
        };
    }

    @Override
    public void focusChanged(boolean focused) {
        if (focused) {
            this.focusedTime = class_156.method_658();
        }
    }

    @Override
    public boolean activate() {
        // Enter 属于换行而不是激活：返回 false 让按键继续交给文本模型
        return false;
    }

    @Override
    public @Nullable class_2561 accessibleName() {
        return accessibleName;
    }

    // 文本变化：超限时整体回退，否则记录并上报
    private void onTextChanged(String text) {
        editSession.changed();
        scrollToCursor();
    }

    // 在子类中读取原版受保护的选择区间，准确保留选择方向。
    private static final class AccessibleTextField extends class_7530 {
        private AccessibleTextField(class_327 font, int width) {
            super(font, width);
        }

        private int anchor() {
            class_7531 selected = method_44427();
            return method_44424() == selected.comp_862() ? selected.comp_863() : selected.comp_862();
        }
    }

    // 按点击位置定位光标
    private void seekCursor(double mouseX, double mouseY) {
        textField.method_44410(scroll.toContentX(mouseX), scroll.toContentY(mouseY));
        scrollToCursor();
    }

    // 让光标所在行保持在可视区内
    private void scrollToCursor() {
        clampScroll();
        int line = Math.max(0, textField.method_44432()) * font.field_2000;
        scroll.ensureVisible(new UiRect(0, line, innerWidth(), font.field_2000));
    }

    // 文本模型宽度为 final，宽度变化时按当前文本与光标重建
    private void ensureTextWidth() {
        int width = innerWidth();
        if (width == textWidth) {
            return;
        }
        UiTextEditSession.Snapshot snapshot = editSession.snapshot();
        this.textWidth = width;
        this.textField = createField(width);
        editSession.restore(snapshot);
        scrollToCursor();
    }

    // 摆放内凹框时把模型坐标贴合矩形
    private void syncBounds() {
        ensureTextWidth();
    }

    // 文本可用宽度（右侧预留滚动条）
    private int innerWidth() {
        return Math.max(8, bounds().width() - PADDING_X * 2 - SCROLLBAR_WIDTH);
    }

    // 文本可视高度
    private int innerHeight() {
        return Math.max(1, bounds().height() - PADDING_Y * 2);
    }

    private void clampScroll() {
        scroll.setViewport(bounds().x() + PADDING_X, bounds().y() + PADDING_Y,
                Math.max(0, bounds().width() - PADDING_X - 1), innerHeight());
        scroll.setContentHeight(textField.method_44430() * font.field_2000);
        scroll.setScrollbarVisible(scroll.maxOffset() > 0);
    }

    private int maxScroll() {
        return scroll.maxOffset();
    }
    /** 文本选择器与可见输入框共用指针归属。 */
    @Override
    public @Nullable UiPointerHit hitTest(double x, double y) {
        if (isVisible()) {
            UiPointerHit scrollHit = scroll.hitTest(x, y);
            if (scrollHit != null) return scrollHit.within(this);
        }
        UiPointerHit hit = UiStatefulWidget.super.hitTest(x, y);
        return hit == null ? null : editSession.includeSelectionOwner(hit);
    }
}
