package com.meteorite.meteosuikit.fabric.client.mixin;

import com.meteorite.meteosuikit.internal.client.UiFrameCaptureState;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Fabric HUD 事件早于 Screen；在整段 GameRenderer 绘制返回后采样。 */
@Mixin(class_757.class)
abstract class FrameCaptureMixin {
    @Inject(method = "render", at = @At("RETURN"))
    private void frameEnded(CallbackInfo callback) { UiFrameCaptureState.frameEnded(); }
}
