package com.meteorite.meteosuikit.api.text;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_327;

/** 注入自然文本宽高，供文档和控件布局在测量阶段读取。 */
public interface TextMeasurer {
    /** 测量组件的自然像素宽度。 */
    int width(class_2561 text);
    /** 按给定宽度分行，保留样式；极窄宽度仍须推进文本，空文本返回空行。 */
    List<class_2561> wrap(class_2561 text, int width);
    /** 当前字体的自然行高。 */
    int lineHeight();

    /** 创建原版 Font 的度量适配器。 */
    static TextMeasurer of(class_327 font) { return new FontMeasurer(font); }

    /** 原版字体适配器，仅在排版阶段测量。 */
    record FontMeasurer(class_327 font) implements TextMeasurer {
        @Override public int width(class_2561 text) { return font.method_27525(text); }
        @Override public List<class_2561> wrap(class_2561 text, int width) {
            return font.method_27527().method_27495(text, Math.max(1, width), class_2583.field_24360).stream().map(line -> {
                var result = class_2561.method_43473();
                line.method_27658((style, value) -> {
                    result.method_10852(class_2561.method_43470(value).method_10862(style));
                    return Optional.empty();
                }, class_2583.field_24360);
                return (class_2561) result;
            }).toList();
        }
        @Override public int lineHeight() { return font.field_2000; }
    }
}
