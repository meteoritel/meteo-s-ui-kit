package com.meteorite.meteosuikit.api.preview;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1921;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_8251;
import com.meteorite.meteosuikit.api.geometry.UiRect;
import com.meteorite.meteosuikit.api.render.UiModelBounds;
import com.meteorite.meteosuikit.api.render.UiRenderLayers;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

/** 唯一三维取景入口：整圈适框、裁剪、光照与 GUI 状态成对恢复。 */
public final class UiSceneView {
    private UiSceneView() { }

    /** 使用模型空间包围绘制已准备场景，转台只改变外部矩阵。 */
    public static void render(class_332 graphics, UiRect box, PreviewScene scene, UiSceneCamera camera, UiSceneStyle style) {
        UiModelBounds bounds = scene.bounds;
        if (scene.state != PreviewState.READY || bounds == null || box.width() <= 2 || box.height() <= 2) return;
        UiRenderLayers.model(graphics, box, local -> renderModel(local, box, scene, bounds, camera, style));
    }

    private static void renderModel(class_332 graphics, UiRect box, PreviewScene scene, UiModelBounds bounds, UiSceneCamera camera, UiSceneStyle style) {
        int target = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        var dispatcher = class_310.method_1551().method_1561();
        Quaternionf previousCamera = new Quaternionf(dispatcher.method_24197());
        boolean depth = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
        float fogStart = RenderSystem.getShaderFogStart(), fogEnd = RenderSystem.getShaderFogEnd();
        var projection = new Matrix4f(RenderSystem.getProjectionMatrix());
        class_8251 previousSorting = RenderSystem.getVertexSorting();
        graphics.method_51452();
        graphics.method_51448().method_22903();
        try {
            float scale = bounds.scale(box, camera.pitch());
            graphics.method_51448().method_46416(box.x() + box.width() / 2.0F, box.y() + box.height() / 2.0F, UiRenderLayers.CONTENT);
            graphics.method_51448().method_23760().method_23761().scale(1, 1, style.depthScale());
            graphics.method_51448().method_22905(scale, -scale, scale);
            Quaternionf orientation = new Quaternionf().rotationX(camera.pitch()).rotateY(camera.yaw());
            graphics.method_51448().method_22907(orientation);
            graphics.method_51448().method_46416(-bounds.centerX(), -bounds.centerY(), -bounds.centerZ());
            class_308.method_34742();
            dispatcher.method_24196(new Quaternionf(orientation).conjugate());
            RenderSystem.enableDepthTest();
            RenderSystem.setShaderFogStart(Float.MAX_VALUE);
            RenderSystem.setShaderFogEnd(Float.MAX_VALUE);
            Matrix4f matrix = new Matrix4f(RenderSystem.getModelViewMatrix()).mul(graphics.method_51448().method_23760().method_23761());
            for (SceneMeshes.Layer layer : scene.layers) if (layer.type != class_1921.method_23583())
                layer.draw(matrix, camera, target);
            RenderSystem.setProjectionMatrix(projection, class_8251.field_43361);
            scene.instances.draw(graphics.method_51448(), graphics.method_51450());
            graphics.method_51450().method_22993();
            RenderSystem.enableDepthTest();
            for (SceneMeshes.Layer layer : scene.layers) if (layer.type == class_1921.method_23583())
                layer.draw(matrix, camera, target);
        } finally {
            try { graphics.method_51452(); }
            finally {
                graphics.method_51448().method_22909();
                dispatcher.method_24196(previousCamera);
                RenderSystem.setProjectionMatrix(projection, previousSorting);
                RenderSystem.setShaderFogStart(fogStart); RenderSystem.setShaderFogEnd(fogEnd);
                class_308.method_24211();
                if (depth) RenderSystem.enableDepthTest(); else RenderSystem.disableDepthTest();
            }
        }
    }
}
