package com.meteorite.meteosuikit.api.preview;

import net.minecraft.class_4588;
import org.jetbrains.annotations.NotNull;

/** 将液体段内顶点平移回局部坐标，并统一满亮；其余属性原样转发。 */
final class SceneVertices implements class_4588 {
    private final class_4588 target;
    private final int x, y, z;
    private final Runnable beforeVertex;
    SceneVertices(class_4588 target, int x, int y, int z) {
        this(target, x, y, z, () -> { });
    }
    SceneVertices(class_4588 target, int x, int y, int z, Runnable beforeVertex) {
        this.target = target; this.x = x; this.y = y; this.z = z;
        this.beforeVertex = beforeVertex;
    }
    @Override public @NotNull class_4588 method_22912(float vx, float vy, float vz) { beforeVertex.run(); target.method_22912(vx + x, vy + y, vz + z); return this; }
    @Override public @NotNull class_4588 method_1336(int r, int g, int b, int a) { target.method_1336(r, g, b, a); return this; }
    @Override public @NotNull class_4588 method_22913(float u, float v) { target.method_22913(u, v); return this; }
    @Override public @NotNull class_4588 method_60796(int u, int v) { target.method_60796(u, v); return this; }
    @Override public @NotNull class_4588 method_22921(int u, int v) { target.method_22921(240, 240); return this; }
    @Override public @NotNull class_4588 method_22914(float nx, float ny, float nz) { target.method_22914(nx, ny, nz); return this; }
}
