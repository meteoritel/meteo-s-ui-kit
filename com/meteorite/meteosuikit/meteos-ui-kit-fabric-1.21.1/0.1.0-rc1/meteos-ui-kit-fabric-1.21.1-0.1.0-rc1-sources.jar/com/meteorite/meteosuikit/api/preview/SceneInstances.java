package com.meteorite.meteosuikit.api.preview;

import com.meteorite.meteosuikit.api.render.UiModelBounds;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_827;
import net.minecraft.class_897;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;


/** 实例只在渲染线程创建和访问，不加入世界、不推进 tick。 */
final class SceneInstances {
    final List<class_2586> blocks = new ArrayList<>();
    final List<class_1297> entities = new ArrayList<>();

    static boolean needsLevel(PreviewSubject subject, @Nullable PreviewStructure structure) {
        return subject instanceof PreviewSubject.Entity || structure != null && (!structure.entities().isEmpty()
                || structure.blocks().stream().anyMatch(cell -> structure.palette().get(cell.state()).method_31709()));
    }

    void prepare(PreviewSubject subject, @Nullable PreviewStructure structure, PreviewScenes.Geometry geometry) {
        class_310 minecraft = class_310.method_1551();
        if (subject instanceof PreviewSubject.Entity actor) addEntity(actor.data(), class_243.field_1353);
        if (structure == null) { entities.forEach(geometry::prepareEntity); return; }
        for (PreviewStructure.Cell cell : structure.blocks()) {
            var state = structure.palette().get(cell.state());
            if (state.method_26204() instanceof class_2343 factory) {
                class_2586 instance = factory.method_10123(cell.pos(), state);
                if (instance == null) continue;
                var level = Objects.requireNonNull(minecraft.field_1687, "方块实体需要客户端世界");
                instance.method_31662(level);
                class_2487 data = cell.data();
                if (data != null) instance.method_58690(data, level.method_30349());
                blocks.add(instance);
            }
        }
        for (PreviewStructure.Actor actor : structure.entities()) addEntity(actor.data(), actor.pos());
        entities.forEach(geometry::prepareEntity);
    }

    private void addEntity(class_2487 data, class_243 pos) {
        class_310 minecraft = class_310.method_1551();
        class_1297 entity = class_1299.method_5892(data, Objects.requireNonNull(minecraft.field_1687, "实体需要客户端世界"))
                .orElseThrow(() -> new IllegalArgumentException("实体类型不可创建: " + data.method_10558("id")));
        entity.method_5808(pos.field_1352, pos.field_1351, pos.field_1350, entity.method_36454(), entity.method_36455());
        entity.field_5982 = entity.method_36454(); entity.field_6004 = entity.method_36455();
        entity.field_6038 = pos.field_1352; entity.field_5971 = pos.field_1351; entity.field_5989 = pos.field_1350;
        if (entity instanceof class_1309 living) {
            living.field_6283 = living.field_6220 = entity.method_36454();
            living.field_6241 = living.field_6259 = entity.method_36454();
        }
        entities.add(entity);
        for (class_2520 passenger : data.method_10554("Passengers", class_2520.field_33260))
            addEntity((class_2487) passenger, pos);
    }

    @Nullable UiModelBounds measure() {
        var dispatcher = class_310.method_1551().method_1561();
        Quaternionf camera = new Quaternionf(dispatcher.method_24197());
        try {
            dispatcher.method_24196(new Quaternionf());
            return UiModelBounds.measure(this::draw);
        } finally { dispatcher.method_24196(camera); }
    }

    void draw(class_4587 pose, class_4597 buffers) {
        for (class_2586 instance : blocks) {
            pose.method_22903();
            try {
                class_2338 p = instance.method_11016();
                pose.method_46416(p.method_10263(), p.method_10264(), p.method_10260());
                drawBlock(instance, pose, buffers);
            } finally { pose.method_22909(); }
        }
        for (class_1297 instance : entities) {
            pose.method_22903();
            try {
                pose.method_22904(instance.method_23317(), instance.method_23318(), instance.method_23321());
                drawEntity(instance, pose, buffers);
            } finally { pose.method_22909(); }
        }
    }

    private static <T extends class_2586> void drawBlock(T instance, class_4587 pose, class_4597 buffers) {
        class_827<T> renderer = class_310.method_1551().method_31975().method_3550(instance);
        if (renderer != null) renderer.method_3569(instance, 0, pose, buffers, 15728880, class_4608.field_21444);
    }

    private static <T extends class_1297> void drawEntity(T entity, class_4587 pose, class_4597 buffers) {
        class_897<? super T> renderer = class_310.method_1551().method_1561().method_3953(entity);
        class_243 offset = renderer.method_23169(entity, 0);
        pose.method_22904(offset.field_1352, offset.field_1351, offset.field_1350);
        renderer.method_3936(entity, entity.method_36454(), 0, pose, buffers, 15728880);
    }

    static @Nullable UiModelBounds union(@Nullable UiModelBounds a, @Nullable UiModelBounds b) {
        if (a == null) return b;
        if (b == null) return a;
        float x0 = Math.min(a.centerX() - a.width() / 2, b.centerX() - b.width() / 2);
        float y0 = Math.min(a.centerY() - a.height() / 2, b.centerY() - b.height() / 2);
        float z0 = Math.min(a.centerZ() - a.depth() / 2, b.centerZ() - b.depth() / 2);
        float x1 = Math.max(a.centerX() + a.width() / 2, b.centerX() + b.width() / 2);
        float y1 = Math.max(a.centerY() + a.height() / 2, b.centerY() + b.height() / 2);
        float z1 = Math.max(a.centerZ() + a.depth() / 2, b.centerZ() + b.depth() / 2);
        return new UiModelBounds((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2, x1 - x0, y1 - y0, z1 - z0);
    }

}
