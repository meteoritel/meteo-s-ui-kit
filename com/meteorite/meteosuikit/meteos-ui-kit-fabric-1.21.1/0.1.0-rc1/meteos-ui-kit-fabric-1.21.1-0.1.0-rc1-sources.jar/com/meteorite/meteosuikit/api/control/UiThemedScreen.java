package com.meteorite.meteosuikit.api.control;

import com.meteorite.meteosuikit.api.geometry.UiRect;
import com.meteorite.meteosuikit.api.style.UiStyleSource;
import com.meteorite.meteosuikit.api.style.UiThemeContext;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;

/** 带完整默认外观的屏幕；背景与内容共用一个稳定 Context，业务排版由子类拥有。 */
public abstract class UiThemedScreen extends UiScreen {
    private final Supplier<? extends UiStyleSource> theme;

    /** 创建 Minecraft 默认屏幕；控件绑定 theme() 即可共享完整外观。 */
    protected UiThemedScreen(class_2561 title) { this(title, UiThemeContext.minecraft()); }

    /** 直接复用宿主 Context，避免屏幕背景与控件出现两个主题所有者。 */
    protected UiThemedScreen(class_2561 title, UiThemeContext<? extends UiStyleSource> theme) {
        super(title);
        this.theme = theme::current;
    }

    /** 屏幕背景与子控件共同读取的稳定来源。 */
    protected final Supplier<? extends UiStyleSource> theme() { return theme; }

    @Override protected void renderGuiBackground(class_332 graphics, int x, int y, float delta) {
        method_25420(graphics, x, y, delta);
    }

    /** 原版背景之后以逻辑坐标绘制主题窗口。 */
    protected void renderThemedBackground(class_332 graphics, int x, int y, float delta) {
        theme.get().drawWindow(graphics, new UiRect(0, 0, viewport().logicalWidth(), viewport().logicalHeight()));
    }

    /** 主题发布、布局和作用域准备完成后，在背景上绘制内容。 */
    protected abstract void renderThemedUi(class_332 graphics, int x, int y, float delta);

    @Override protected final void renderUi(class_332 graphics, int x, int y, float delta) {
        renderThemedBackground(graphics, x, y, delta);
        renderThemedUi(graphics, x, y, delta);
    }
}
