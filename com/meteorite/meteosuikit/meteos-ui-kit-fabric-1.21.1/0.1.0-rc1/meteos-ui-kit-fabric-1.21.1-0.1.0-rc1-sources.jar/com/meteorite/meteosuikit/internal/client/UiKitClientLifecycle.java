package com.meteorite.meteosuikit.internal.client;

import com.meteorite.meteosuikit.internal.render.UiModelSurface;
import net.minecraft.class_2246;
import net.minecraft.class_2477;
import net.minecraft.class_310;
import org.jetbrains.annotations.Nullable;

/** 库持有的共享绘制工作区生命周期，独立于可选场景内容。 */
public final class UiKitClientLifecycle {
    private static long generation;
    private static @Nullable Object world;
    private static @Nullable Object language;
    private static @Nullable Object models;

    private UiKitClientLifecycle() { }

    /** 客户端 tick 观察共享工作区的资源身份，宿主自行使业务缓存失效。 */
    public static void observe() {
        class_310 minecraft = class_310.method_1551();
        Object nextModels = minecraft.method_1541().method_3351()
                .method_3335(class_2246.field_10340.method_9564());
        Object nextLanguage = class_2477.method_10517();
        if (world != minecraft.field_1687 || language != nextLanguage || models != nextModels) {
            generation++;
            UiModelSurface.release();
            world = minecraft.field_1687;
            language = nextLanguage;
            models = nextModels;
        }
    }

    /** GUI 根用同一资源世代失效自身缓存，读取不触发资源操作。 */
    public static long generation() { return generation; }

    /** 客户端终止时释放共享 GPU 工作区。 */
    public static void release() {
        UiFrameCaptureState.release();
        UiModelSurface.release();
        world = null;
        language = null;
        models = null;
    }
}
