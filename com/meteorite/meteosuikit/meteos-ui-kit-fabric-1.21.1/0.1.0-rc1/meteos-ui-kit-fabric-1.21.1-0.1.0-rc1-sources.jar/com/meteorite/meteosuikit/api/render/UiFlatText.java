package com.meteorite.meteosuikit.api.render;

import com.meteorite.meteosuikit.api.geometry.UiRect;
import com.meteorite.meteosuikit.api.style.UiSurfaceStyle;
import com.meteorite.meteosuikit.api.style.UiTooltipSkin;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5481;

/**
 * 全 GUI 共用的无阴影文本绘制：原版 {@code drawCenteredString}、{@code drawWordWrap} 与悬停提示都会给字形叠加暗色阴影，
 * 深色文本叠在浅色底板上时阴影与笔画糊在一起，因此这些场景统一改由本类逐行 {@code drawString(..., false)} 绘制。
 *
 * <p>悬停提示保留原版的深色底板与渐变描边观感，只去掉文字阴影；顶部优先从指针上方展开，越界时翻转并钳制在屏幕内。</p>
 */
public final class UiFlatText {
    // 首行之后额外让出的间距，与原版提示的行距一致
    private static final int TOOLTIP_FIRST_LINE_GAP = 2;

    private UiFlatText() { }

    /**
     * 居中绘制单行文本，替代强制带阴影的 {@link class_332#method_25300}。
     *
     * @param graphics 绘制上下文
     * @param font 绘制字体
     * @param text 待绘制文本
     * @param centerX 文本中心的屏幕 X 坐标
     * @param y 文本顶部的屏幕 Y 坐标
     * @param color 文本颜色
     */
    public static void drawCentered(class_332 graphics, class_327 font, class_2561 text, int centerX, int y, int color) {
        graphics.method_51439(font, text, centerX - font.method_27525(text) / 2, y, color, false);
    }

    /**
     * 居中绘制单行文本，替代强制带阴影的 {@link class_332#method_25300}。
     *
     * @param graphics 绘制上下文
     * @param font 绘制字体
     * @param text 待绘制文本
     * @param centerX 文本中心的屏幕 X 坐标
     * @param y 文本顶部的屏幕 Y 坐标
     * @param color 文本颜色
     */
    public static void drawCentered(class_332 graphics, class_327 font, String text, int centerX, int y, int color) {
        graphics.method_51433(font, text, centerX - font.method_1727(text) / 2, y, color, false);
    }

    /**
     * 按宽度折行后逐行绘制，替代强制带阴影的 {@link class_332#method_51440}。
     *
     * @param graphics 绘制上下文
     * @param font 绘制字体
     * @param text 待绘制文本
     * @param x 文本区左侧屏幕 X 坐标
     * @param y 文本区顶部屏幕 Y 坐标
     * @param width 折行宽度
     * @param color 文本颜色
     */
    public static void drawWrapped(class_332 graphics, class_327 font, class_2561 text, int x, int y, int width, int color) {
        int lineY = y;
        for (class_5481 line : font.method_1728(text, Math.max(1, width))) {
            graphics.method_51430(font, line, x, lineY, color, false);
            lineY += font.field_2000;
        }
    }

    /**
     * 绘制已折行的悬停提示。
     *
     * @param graphics 绘制上下文
     * @param font 绘制字体
     * @param lines 已折行的提示文本行
     * @param mouseX 指针屏幕 X 坐标
     * @param mouseY 指针屏幕 Y 坐标
     */
    public static void tooltip(class_332 graphics, class_327 font, List<class_5481> lines, int mouseX, int mouseY) {
        tooltip(graphics, font, new UiRect(0, 0, graphics.method_51421(), graphics.method_51443()), lines, mouseX, mouseY, UiTooltipSkin.MINECRAFT);
    }

    private static void tooltip(class_332 graphics, class_327 font, UiRect host,
                                List<class_5481> lines, int mouseX, int mouseY, UiTooltipSkin skin) {
        if (lines.isEmpty() || UiTooltipPanel.contentWidth(host, Integer.MAX_VALUE,
                skin.padding(), UiTooltipPanel.SCREEN_MARGIN) == 0) return;
        int widest = 0;
        for (class_5481 line : lines) {
            widest = Math.max(widest, font.method_30880(line));
        }
        int height = lines.size() * font.field_2000 + (lines.size() > 1 ? TOOLTIP_FIRST_LINE_GAP : 0);
        UiTooltipPanel panel = UiTooltipPanel.layout(host,
                widest, height, skin.padding(), mouseX, mouseY);
        panel.render(graphics, rect -> skin.paint(graphics, rect), content -> {
            int lineY = content.y();
            for (int index = 0; index < lines.size(); index++) {
                graphics.method_51430(font, lines.get(index), content.x(), lineY, skin.style().tooltipText(), false);
                lineY += font.field_2000 + (index == 0 ? TOOLTIP_FIRST_LINE_GAP : 0);
            }
        });
    }

    /**
     * 按最大宽度折行后绘制悬停提示。
     *
     * @param graphics 绘制上下文
     * @param font 绘制字体
     * @param text 提示文本，可自带换行
     * @param maxWidth 折行宽度上限
     * @param mouseX 指针屏幕 X 坐标
     * @param mouseY 指针屏幕 Y 坐标
     */
    public static void tooltip(class_332 graphics, class_327 font, class_2561 text, int maxWidth, int mouseX, int mouseY) {
        componentTooltip(graphics, font, List.of(text), maxWidth, mouseX, mouseY);
    }

    /** 单个提示组件使用根主题语义色，折行与面板位置沿用同一算法。 */
    public static void tooltip(class_332 graphics, class_327 font, class_2561 text, int maxWidth,
                               int mouseX, int mouseY, UiSurfaceStyle style) {
        componentTooltip(graphics, font, new UiRect(0, 0, graphics.method_51421(), graphics.method_51443()),
                List.of(text), maxWidth, mouseX, mouseY, UiTooltipSkin.minecraft(style));
    }

    /**
     * 绘制由多个组件组成的悬停提示：每个组件按最大宽度折行后拼成整块提示。
     *
     * @param graphics 绘制上下文
     * @param font 绘制字体
     * @param lines 提示文本行，每项可自带换行
     * @param maxWidth 折行宽度上限
     * @param mouseX 指针屏幕 X 坐标
     * @param mouseY 指针屏幕 Y 坐标
     */
    public static void componentTooltip(class_332 graphics, class_327 font, List<class_2561> lines, int maxWidth, int mouseX, int mouseY) {
        componentTooltip(graphics, font, new UiRect(0, 0, graphics.method_51421(), graphics.method_51443()),
                lines, maxWidth, mouseX, mouseY);
    }

    /** 在有限宿主内先预算正文宽度，再折行和放置面板。 */
    public static void componentTooltip(class_332 graphics, class_327 font, UiRect host, List<class_2561> lines,
                                        int maxWidth, int mouseX, int mouseY) {
        componentTooltip(graphics, font, host, lines, maxWidth, mouseX, mouseY, UiTooltipSkin.MINECRAFT);
    }

    /** 显式结构色沿用原版提示画法，供 library 宿主使用。 */
    @SuppressWarnings("unused")
    public static void componentTooltip(class_332 graphics, class_327 font, UiRect host, List<class_2561> lines,
                                        int maxWidth, int mouseX, int mouseY, UiSurfaceStyle style) {
        componentTooltip(graphics, font, host, lines, maxWidth, mouseX, mouseY, UiTooltipSkin.minecraft(style));
    }

    /** 使用完整主题 skin，折行和定位由通用呈现负责。 */
    public static void componentTooltip(class_332 graphics, class_327 font, UiRect host, List<class_2561> lines,
                                        int maxWidth, int mouseX, int mouseY, UiTooltipSkin skin) {
        int width = UiTooltipPanel.contentWidth(host, maxWidth, skin.padding(), UiTooltipPanel.SCREEN_MARGIN);
        if (width == 0) return;
        List<class_5481> sequences = new ArrayList<>();
        for (class_2561 line : lines) sequences.addAll(font.method_1728(line, width));
        tooltip(graphics, font, host, sequences, mouseX, mouseY, skin);
    }

    /** 单个主题提示的完整 skin 入口。 */
    public static void tooltip(class_332 graphics, class_327 font, class_2561 text, int maxWidth,
                               int mouseX, int mouseY, UiTooltipSkin skin) {
        componentTooltip(graphics, font, new UiRect(0, 0, graphics.method_51421(), graphics.method_51443()),
                List.of(text), maxWidth, mouseX, mouseY, skin);
    }
}
