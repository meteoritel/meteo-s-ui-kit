package com.meteorite.meteosuikit.fabric.client;

import com.meteorite.meteosuikit.api.preview.PreviewScenes;
import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.minecraft.class_8113;
import com.meteorite.meteosuikit.internal.preview.mixin.DisplayPreviewAccessor;
import org.jetbrains.annotations.NotNull;

/** Fabric 预览复用原版区块模型和液体渲染契约。 */
public final class FabricPreviewGeometry implements PreviewScenes.Geometry {
    /** 显示实体从载荷直接生成渲染快照；其他实体沿用加载后的状态。 */
    @Override public void prepareEntity(@NotNull class_1297 entity) {
        if (entity instanceof class_8113) {
            DisplayPreviewAccessor access = (DisplayPreviewAccessor) entity;
            access.previewSetRenderState(access.previewCreateRenderState());
            access.previewUpdateSubState(false, 0);
        }
    }

    /** 按原版方块层启用邻面剔除。 */
    @Override public void block(@NotNull class_2680 state, @NotNull class_2338 pos, @NotNull class_1920 blocks, @NotNull class_4587 pose,
            @NotNull Function<class_1921, class_4588> buffers, @NotNull class_5819 random) {
        class_310.method_1551().method_1541().method_3355(state, pos, blocks, pose,
                buffers.apply(class_4696.method_23679(state)), true, random);
    }
    /** 使用原版液体模型和对应渲染层。 */
    @Override public void fluid(@NotNull class_2338 pos, @NotNull class_1920 blocks, @NotNull Function<class_1921, class_4588> buffers,
            @NotNull class_2680 state, @NotNull class_3610 fluid) {
        class_310.method_1551().method_1541().method_3352(pos, blocks,
                buffers.apply(class_4696.method_23680(fluid)), state, fluid);
    }
}
