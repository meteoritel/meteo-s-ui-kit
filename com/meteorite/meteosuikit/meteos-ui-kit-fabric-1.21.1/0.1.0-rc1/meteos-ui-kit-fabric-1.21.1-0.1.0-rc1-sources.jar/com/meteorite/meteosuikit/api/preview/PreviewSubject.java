package com.meteorite.meteosuikit.api.preview;

import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import org.jetbrains.annotations.Nullable;

/** 展示内容的值快照；调用方修改原始 stack 或 NBT 不会改变场景身份。 */
public sealed interface PreviewSubject {
    /** 原版 GUI 物品；数量和组件共同参与缓存身份。 */
    record Item(class_1799 stack) implements PreviewSubject {
        public Item { stack = stack.method_7972(); }
        /** 返回展示快照的副本。 */
        @Override public class_1799 stack() { return stack.method_7972(); }
        @Override public boolean equals(Object other) {
            return other instanceof Item item && class_1799.method_7973(stack, item.stack);
        }
        @Override public int hashCode() {
            return 31 * class_1799.method_57355(stack) + stack.method_7947();
        }
    }

    /** 放置态方块，载荷用于真实方块实体 renderer。 */
    record Block(class_2680 state, @Nullable class_2487 blockEntityData) implements PreviewSubject {
        public Block { blockEntityData = blockEntityData == null ? null : blockEntityData.method_10553(); }
        /** 返回独立载荷副本。 */
        @Override public @Nullable class_2487 blockEntityData() {
            return blockEntityData == null ? null : blockEntityData.method_10553();
        }
    }

    /** 流体放置态，保留源流体或流动状态。 */
    record Fluid(class_3610 state) implements PreviewSubject { }

    /** 含 id、朝向与展示参数的完整实体 NBT。 */
    record Entity(class_2487 data) implements PreviewSubject {
        public Entity { data = data.method_10553(); }
        /** 返回独立载荷副本。 */
        @Override public class_2487 data() { return data.method_10553(); }
    }

    /** 已解码的客户端结构。 */
    final class Structure implements PreviewSubject {
        private final PreviewStructure value;
        private final int hash;

        /** 结构不可变，内容哈希只在交接时计算，绘制时查缓存保持常数成本。 */
        public Structure(PreviewStructure value) { this.value = value; this.hash = value.hashCode(); }
        /** 返回已验证的不可变结构。 */
        public PreviewStructure value() { return value; }
        @Override public int hashCode() { return hash; }
        @Override public boolean equals(Object other) {
            return this == other || other instanceof Structure structure
                    && hash == structure.hash && value.equals(structure.value);
        }
    }
}
