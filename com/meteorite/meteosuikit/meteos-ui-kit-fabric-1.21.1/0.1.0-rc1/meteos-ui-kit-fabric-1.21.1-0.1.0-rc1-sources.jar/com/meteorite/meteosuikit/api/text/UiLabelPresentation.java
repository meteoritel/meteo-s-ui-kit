package com.meteorite.meteosuikit.api.text;

import com.meteorite.meteosuikit.api.geometry.UiRect;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5481;
import org.jetbrains.annotations.Nullable;

/**
 * 一段标签的测量与悬停呈现。实例归控件或稳定行持有，包装与核心可共享；
 * 字体及语言资源变化使测量失效，文本带、颜色与悬停门禁由调用方提供。
 */
public final class UiLabelPresentation {
    private class_2561 text = class_2561.method_43473();
    private class_5481 visualText = class_5481.field_26385;
    private @Nullable class_327 measuredFont;
    private @Nullable class_2477 measuredLanguage;
    private int width;
    private int hoverTicks;

    /**
     * 当前语义文本，供名称、提示与布局快照共用。
     */
    public class_2561 text() {
        return text;
    }

    /**
     * 内容改变后重新测量并重置滚动；相同内容保持当前呈现。
     */
    public void setText(class_2561 next) {
        if (text.equals(next)) return;
        text = next.method_27661();
        measuredFont = null;
        hoverTicks = 0;
    }

    /**
     * 读取当前字体与语言下的测量宽度，稳定帧复用缓存。
     */
    public int width(class_327 font) {
        refreshMetrics(font);
        return width;
    }

    /**
     * 在给定文本带内左对齐绘制；hovered 已包含作用域与几何门禁，离开即重置滚动。
     * 文本超宽时复用 TextScroll 的滚动与裁剪。
     */
    public void render(class_332 graphics, class_327 font, UiRect band, int color, boolean hovered) {
        refreshMetrics(font);
        hoverTicks = hovered ? hoverTicks + 1 : 0;
        TextScroll.draw(graphics, font, visualText, width, band.x(), band.y(), band.width(),
                color, hovered, hoverTicks);
    }

    private void refreshMetrics(class_327 font) {
        class_2477 language = class_2477.method_10517();
        if (measuredFont == font && measuredLanguage == language) return;
        measuredFont = font;
        measuredLanguage = language;
        hoverTicks = 0;
        visualText = text.method_30937();
        width = font.method_30880(visualText);
    }
}
